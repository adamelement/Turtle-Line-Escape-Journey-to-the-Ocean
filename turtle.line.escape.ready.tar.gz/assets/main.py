"""Turtle Line Escape: Journey to the Ocean, procedural Pygame graphics.
Pygame only; no image assets. Maximize the window in any round; F11 toggles fullscreen.
Click the corner box / Enter: equation; G: grid; M: menu; click Pause to pause.
Escape exits fullscreen or closes equation/menu entry.
Equal-sized grid units fill the view; resizing preserves the round coordinates.
"""
import asyncio
import os
import ast
import heapq
import math
import random
import re

import pygame
import pygame.gfxdraw

pygame.init()

# -------------------- WINDOW / GRAPH --------------------
BASE_WIDTH, BASE_HEIGHT = 1600, 900
BASE_X, BASE_Y = 320 / 9, 20.0
BASE_SCALE = BASE_HEIGHT / (2 * BASE_Y)
MIN_VISIBLE_Y = 17.5  # preserve the route in exceptionally short / ultrawide windows
START_EDGE_GAP = 6.0  # approximate pixels at the base drawing size
WIDTH, HEIGHT = 1200, 675
GRAPH_SIZE = min(WIDTH, HEIGHT)
GRAPH_LEFT = (WIDTH-GRAPH_SIZE)//2
GRAPH_TOP = 0
PANEL_LEFT = 820

MIN_COORD = -20
MAX_COORD = 20
SCALE = HEIGHT / (MAX_COORD - MIN_COORD)

display_info=pygame.display.Info()
WINDOW = pygame.display.set_mode((min(WIDTH,max(640,display_info.current_w-40)),
                                  min(HEIGHT,max(480,display_info.current_h-70))),pygame.RESIZABLE)
SCREEN = pygame.Surface((WIDTH, HEIGHT)).convert()
GRAPH_W = GRAPH_SIZE
X_MIN, X_MAX, Y_MIN, Y_MAX = -20.0, 20.0, -20.0, 20.0
pygame.display.set_caption("Turtle Line Escape: Journey to the Ocean")
CLOCK = pygame.time.Clock()

# Ship the same fonts to desktop and pygbag; system fonts differ between devices.
FONT_DIRECTORY = os.path.join(os.path.dirname(os.path.abspath(__file__)), "fonts")
def game_font(size, bold=False):
    filename = "LiberationSans-Bold.ttf" if bold else "LiberationSans-Regular.ttf"
    return pygame.font.Font(os.path.join(FONT_DIRECTORY, filename), size)

FONT = game_font(23)
SMALL_FONT = game_font(18)
INTRO_FONT = game_font(22)
EQUATION_LABEL_FONT = game_font(22, bold=True)
TINY_FONT = game_font(16)
BIG_FONT = game_font(34, bold=True)
TITLE_FONT = game_font(27, bold=True)

WHITE = (255, 255, 255)
BLACK = (25, 25, 25)
GRID = (204, 181, 137)
AXIS = (117, 105, 79)
BLUE = (45, 105, 210)
RED = (210, 65, 65)
GREEN = (30, 145, 75)
DARK_GREEN = (15, 105, 55)
ORANGE = (235, 145, 40)
PURPLE = (125, 80, 190)
BROWN = (130, 90, 55)
GREY = (105, 104, 88)
LIGHT_PANEL = (248, 243, 230)
YELLOW = (245, 205, 55)
ROCK_DARK = (83, 91, 100)
ROCK_BASE = (137, 146, 155)


HAWK_COUNTS = [2, 3, 5, 7, 11, 13, 17, 19, 23, 29]

# Physical platforms. Their sides and heights are randomized each round.
LEFT_LEDGE = (MIN_COORD, -15.0)
RIGHT_LEDGE = (15.0, MAX_COORD)
PLATFORM_MIN_Y = -15
PLATFORM_MAX_Y = 15
MIN_PLATFORM_HEIGHT_DIFFERENCE = 4

# Each round has one obstacle, with a 50% chance of a second.
MIN_OBSTACLES = 1
MAX_OBSTACLES = 2

OBJECT_SCALE = 1.15
MOVEMENT_SCALE = 1.15
TURBO_DURATION = 3.0
SHELL_DURATION = 3.0
TURBO_MULTIPLIER = 2.9
TURTLE_SPEED = 3.5 * MOVEMENT_SCALE * 1.08  # graph units / second
FALL_SPEED = 8.0
TURTLE_RADIUS = 0.55 * OBJECT_SCALE
HAWK_RADIUS = 0.38
HAWK_DRAW_WIDTH = 66
HAWK_DRAW_HEIGHT = 43
# The drawing faces right and its beak is close to the right edge.
HAWK_BEAK_REACH = 22.0 / (850/40)
INTERSECTION_TOL = 0.85
INTERSECTION_GRACE = 0.0
LAND_TOL = 0.18
PATH_CLEARANCE = TURTLE_RADIUS + 0.08


def distance_to_segment(px, py, x1, y1, x2, y2):
    """Shortest distance from a point to a line segment."""
    vx, vy = x2 - x1, y2 - y1
    length_sq = vx * vx + vy * vy
    if length_sq == 0:
        return math.hypot(px - x1, py - y1)
    t = max(0.0, min(1.0, ((px - x1) * vx + (py - y1) * vy) / length_sq))
    return math.hypot(px - (x1 + t * vx), py - (y1 + t * vy))


def segment_distance(a,b,c,d):
    """Distance between two finite segments, including crossing and zero-length cases."""
    def cross(u,v):return u[0]*v[1]-u[1]*v[0]
    ab=(b[0]-a[0],b[1]-a[1]);cd=(d[0]-c[0],d[1]-c[1])
    denominator=cross(ab,cd)
    if abs(denominator)>1e-12:
        ac=(c[0]-a[0],c[1]-a[1])
        t=cross(ac,cd)/denominator;u=cross(ac,ab)/denominator
        if 0<=t<=1 and 0<=u<=1:return 0.0
    return min(distance_to_segment(*a,*c,*d),distance_to_segment(*b,*c,*d),
               distance_to_segment(*c,*a,*b),distance_to_segment(*d,*a,*b))


def point_in_polygon(px, py, polygon):
    """Ray-casting test for a point inside a polygon."""
    inside = False
    j = len(polygon) - 1
    for i, (xi, yi) in enumerate(polygon):
        xj, yj = polygon[j]
        if (yi > py) != (yj > py):
            intersection_x = (xj - xi) * (py - yi) / (yj - yi) + xi
            if px < intersection_x:
                inside = not inside
        j = i
    return inside


# -------------------- HELPERS --------------------
def graph_to_screen(gx, gy):
    sx = GRAPH_LEFT + (gx - X_MIN) * SCALE
    sy = GRAPH_TOP + (Y_MAX - gy) * SCALE
    return int(round(sx)), int(round(sy))


def screen_inside_graph(sx, sy):
    return (
        GRAPH_LEFT <= sx <= GRAPH_LEFT + GRAPH_W
        and GRAPH_TOP <= sy <= GRAPH_TOP + GRAPH_SIZE
    )


def clean_math_text(text):
    """Make equation input easier to parse."""
    return text.strip().lower().replace(" ", "").replace("−", "-")


def parse_number(text):
    """Convert a simple signed decimal/fraction to a float."""
    text = text.strip()
    if text in ("", "+"):
        return 1.0
    if text == "-":
        return -1.0

    if "/" in text:
        if text.count("/") != 1:
            raise ValueError("Use a simple number or fraction.")
        numerator, denominator = text.split("/")
        value = float(numerator) / float(denominator)
        return value

    return float(text)


def parse_linear_equation(text):
    """Reduce either side of a linear equation to ax + by + c, without eval."""
    original=text.strip();raw=clean_math_text(text).replace("^","**")
    if len(raw)>600 or raw.count("=")!=1:raise ValueError("Enter one linear equation with one equals sign.")
    def expression(part):
        if not part:raise ValueError("Enter an expression on both sides of the equals sign.")
        tokens=re.findall(r"(?:\d+(?:\.\d*)?|\.\d+)(?:e[+-]?\d+)?|[xy]|\*\*|[()+*/-]",part)
        if "".join(tokens)!=part:raise ValueError("Use numbers, x, y, brackets and arithmetic signs.")
        built=[]
        for token in tokens:
            if built:
                prev=last
                end=prev in ("x","y",")") or prev[0].isdigit() or prev[0]=="."
                start=token in ("x","y","(") or token[0].isdigit() or token[0]=="."
                if end and start:built.append("*")
            built.append(token);last=token
        try:tree=ast.parse("".join(built),mode="eval")
        except (SyntaxError,RecursionError):raise ValueError("Check the brackets and arithmetic in your equation.")
        if sum(1 for _ in ast.walk(tree))>180:raise ValueError("Please use a shorter equation.")
        def constant(v):return abs(v[0])+abs(v[1])<1e-12
        def visit(node):
            if isinstance(node,ast.Constant) and type(node.value) in (int,float):return (0.0,0.0,float(node.value))
            if isinstance(node,ast.Name) and node.id in ("x","y"):return (1.0,0.0,0.0) if node.id=="x" else (0.0,1.0,0.0)
            if isinstance(node,ast.UnaryOp) and isinstance(node.op,(ast.UAdd,ast.USub)):
                v=visit(node.operand);return tuple(-x for x in v) if isinstance(node.op,ast.USub) else v
            if isinstance(node,ast.BinOp):
                l,r=visit(node.left),visit(node.right)
                if isinstance(node.op,(ast.Add,ast.Sub)):
                    sign=-1 if isinstance(node.op,ast.Sub) else 1;return tuple(a+sign*b for a,b in zip(l,r))
                if isinstance(node.op,ast.Mult):
                    if constant(l):return tuple(l[2]*v for v in r)
                    if constant(r):return tuple(r[2]*v for v in l)
                if isinstance(node.op,ast.Div) and constant(r):
                    if abs(r[2])<1e-12:raise ValueError("Division by zero is not allowed.")
                    return tuple(v/r[2] for v in l)
                if isinstance(node.op,ast.Pow) and constant(r):
                    if r[2]==1:return l
                    if r[2]==0:return (0.0,0.0,1.0)
                    if constant(l) and abs(r[2])<=12:return (0.0,0.0,l[2]**r[2])
            raise ValueError("Use a linear equation; do not multiply or divide variables together.")
        try:result=visit(tree.body)
        except (OverflowError,ZeroDivisionError,TypeError):raise ValueError("The numbers in this equation are too large or undefined.")
        if any(not isinstance(v,(int,float)) or not math.isfinite(v) or abs(v)>1e12 for v in result):raise ValueError("Use smaller, finite numbers.")
        return result
    left,right=map(expression,raw.split("="));A,B,C=(a-b for a,b in zip(left,right))
    if abs(A)+abs(B)<1e-10:raise ValueError("This equation does not define a single straight line.")
    return Line(A,B,C,original)


def point_on_segment(px, py, x1, y1, x2, y2, tol=0.25):
    cross = abs((px - x1) * (y2 - y1) - (py - y1) * (x2 - x1))
    length = math.hypot(x2 - x1, y2 - y1)
    if length == 0 or cross / length > tol:
        return False
    dot = (px - x1) * (px - x2) + (py - y1) * (py - y2)
    return dot <= tol


def wrap_text(text, font, max_width):
    words = text.split()
    lines, current = [], ""
    for word in words:
        trial = word if not current else current + " " + word
        if font.size(trial)[0] <= max_width:
            current = trial
        else:
            if current:
                lines.append(current)
            current = word
    if current:
        lines.append(current)
    return lines


# -------------------- LINE OBJECT --------------------
class Line:
    def __init__(self, A, B, C, label=""):
        self.A = A
        self.B = B
        self.C = C
        self.label = label
        # A direction vector along Ax + By + C = 0 is (B, -A)
        length = math.hypot(B, -A)
        self.dx = B / length
        self.dy = -A / length

    @property
    def vertical(self):
        return abs(self.B) < 1e-9

    def signed_value(self, px, py):
        return self.A * px + self.B * py + self.C

    def intersection(self, other):
        det = self.A * other.B - other.A * self.B
        if abs(det) < 1e-9:
            return None
        ix = (self.B * other.C - other.B * self.C) / det
        iy = (self.C * other.A - other.C * self.A) / det
        return ix, iy

    def visible_endpoints(self):
        pts = []

        if abs(self.B) > 1e-9:
            for gx in (X_MIN, X_MAX):
                gy = -(self.A * gx + self.C) / self.B
                if Y_MIN - 1e-8 <= gy <= Y_MAX + 1e-8:
                    pts.append((gx, gy))

        if abs(self.A) > 1e-9:
            for gy in (Y_MIN, Y_MAX):
                gx = -(self.B * gy + self.C) / self.A
                if X_MIN - 1e-8 <= gx <= X_MAX + 1e-8:
                    pts.append((gx, gy))

        unique = []
        for p in pts:
            if not any(math.dist(p, q) < 1e-6 for q in unique):
                unique.append(p)
        return unique[:2]

    def y_at(self, gx):
        if abs(self.B) < 1e-9:
            return None
        return -(self.A * gx + self.C) / self.B


# -------------------- UI --------------------
class InputBox:
    def __init__(self, x0, y0, w, h):
        self.rect = pygame.Rect(x0, y0, w, h)
        self.text = ""
        self.active = False

    def handle_event(self, event):
        submitted = False
        empty_backspace = False

        if event.type == pygame.MOUSEBUTTONDOWN:
            self.active = self.rect.collidepoint(event.pos)

        if event.type == pygame.KEYDOWN and self.active:
            if event.key == pygame.K_RETURN:
                submitted = True
            elif event.key == pygame.K_BACKSPACE:
                if self.text:
                    self.text = self.text[:-1]
                else:
                    empty_backspace = True
            elif event.unicode and event.unicode.isprintable():
                self.text += event.unicode

        return submitted, empty_backspace

    def draw(self):
        colour = BLUE if self.active else GREY
        pygame.draw.rect(SCREEN, WHITE, self.rect)
        pygame.draw.rect(SCREEN, colour, self.rect, 2, border_radius=5)
        txt = FONT.render(self.text, True, BLACK)
        old_clip=SCREEN.get_clip()
        SCREEN.set_clip(self.rect.inflate(-12,-4))
        text_x=min(self.rect.x+8,self.rect.right-8-txt.get_width()) if txt.get_width()>self.rect.width-16 else self.rect.x+8
        SCREEN.blit(txt,(text_x,self.rect.y+7))
        SCREEN.set_clip(old_clip)


class Button:
    def __init__(self, x0, y0, w, h, text):
        self.rect = pygame.Rect(x0, y0, w, h)
        self.text = text

    def clicked(self, event):
        return event.type == pygame.MOUSEBUTTONDOWN and self.rect.collidepoint(event.pos)

    def draw(self):
        pygame.draw.rect(SCREEN, WHITE, self.rect, border_radius=7)
        pygame.draw.rect(SCREEN, BLUE, self.rect, 2, border_radius=7)
        surf = FONT.render(self.text, True, BLUE)
        SCREEN.blit(
            surf,
            (
                self.rect.centerx - surf.get_width() // 2,
                self.rect.centery - surf.get_height() // 2,
            ),
        )


def make_ground_shadow(sprite, opacity=54, softness=4, size_factor=1.0):
    """Create a softly blurred silhouette once, then reuse it while the animal moves."""
    tint=pygame.Surface(sprite.get_size(),pygame.SRCALPHA)
    pygame.mask.from_surface(sprite).to_surface(surface=tint,
        setcolor=(61,47,29,opacity),unsetcolor=(0,0,0,0))
    if size_factor!=1:
        tint=pygame.transform.smoothscale(tint,(max(1,round(tint.get_width()*size_factor)),
                                               max(1,round(tint.get_height()*size_factor))))
    pad=softness*2
    shadow=pygame.Surface((tint.get_width()+pad*2,tint.get_height()+pad*2),pygame.SRCALPHA)
    shadow.blit(tint,(pad,pad))
    reduced=(max(1,shadow.get_width()//softness),max(1,shadow.get_height()//softness))
    return pygame.transform.smoothscale(pygame.transform.smoothscale(shadow,reduced),shadow.get_size())


# -------------------- HAWKS --------------------
class Hawk:
    def __init__(self, line, t, direction, speed, kind="brown"):
        self.line = line
        self.t = t
        self.direction = direction
        self.speed = speed
        self.kind=kind
        self.previous_position=self.position();self.previous_direction=direction
        self.size_factor=(2.4 if kind=="red" else 1.0)*OBJECT_SCALE
        self.radius=HAWK_RADIUS*self.size_factor
        self.beak_reach=HAWK_BEAK_REACH*self.size_factor
        if not hasattr(Hawk,"_pose_cache"):Hawk._pose_cache={}
        if kind not in Hawk._pose_cache:
            frames=[]
            for frame in range(96):
                sprite=self.make_surface(math.tau*frame/96)
                shadow=make_ground_shadow(sprite,opacity=48,softness=5,size_factor=.90)
                frames.append((sprite,shadow))
            Hawk._pose_cache[kind]=frames
        self.frames=Hawk._pose_cache[kind]
        self.wing_phase=0.0
        self.wing_period=random.uniform(1.08,1.20)
        self.flaps_remaining=random.randint(2,7)
        self.gliding=random.random()<.35
        self.glide_remaining=random.uniform(1.5,3.0) if self.gliding else 0.0
        self.wing_phase=0.0
        self.completed_flaps=0
        self.set_wing_pose()

    def set_wing_pose(self):
        frame=0 if self.gliding else int(self.wing_phase*len(self.frames))%len(self.frames)
        self.sprite,self.shadow=self.frames[frame]

    def update_wings(self, dt):
        # Consume overshoot so the rhythm is independent of frame rate.
        remaining=max(0.0,dt)
        while remaining>1e-9:
            if self.gliding:
                step=min(remaining,self.glide_remaining)
                remaining-=step;self.glide_remaining-=step
                if self.glide_remaining<=1e-9:
                    self.gliding=False
                    self.flaps_remaining=random.randint(2,7)
                    self.wing_period=random.uniform(1.08,1.20)
                    self.wing_phase=0.0
            else:
                step=min(remaining,(1.0-self.wing_phase)*self.wing_period)
                remaining-=step;self.wing_phase+=step/self.wing_period
                if self.wing_phase>=1.0-1e-9:
                    self.wing_phase=0.0
                    self.flaps_remaining-=1
                    self.completed_flaps+=1
                    if self.flaps_remaining==0:
                        self.gliding=True
                        self.glide_remaining=random.uniform(1.5,3.0)
        self.set_wing_pose()

    def position(self):
        if hasattr(self,"trap_position"):return self.trap_position
        # point nearest origin on line, plus t * direction vector
        denom = self.line.A ** 2 + self.line.B ** 2
        bx = -self.line.A * self.line.C / denom
        by = -self.line.B * self.line.C / denom
        return bx + self.line.dx * self.t, by + self.line.dy * self.t

    def update(self, dt):
        self.update_wings(dt)
        old_t = self.t
        old_x, old_y = self.position()
        self.previous_position=(old_x,old_y);self.previous_direction=self.direction

        self.t += self.direction * self.speed * dt
        nx, ny = self.position()

        # Reverse when the forward tip of the beak reaches a graph boundary.
        forward_x = self.line.dx * self.direction
        forward_y = self.line.dy * self.direction
        beak_x = nx + forward_x * self.beak_reach
        beak_y = ny + forward_y * self.beak_reach
        if not (X_MIN <= beak_x <= X_MAX and Y_MIN <= beak_y <= Y_MAX):
            endpoints=self.line.visible_endpoints()
            if len(endpoints)==2:
                low,high=sorted(x*self.line.dx+y*self.line.dy for x,y in endpoints)
                margin=min(self.beak_reach,(high-low)*.35)
                self.t=high-margin if self.direction>0 else low+margin
            else:self.t=old_t
            self.direction *= -1
            return


    def touches_turtle(self,previous,current,angle=0.0,previous_angle=None,tuck=0.0):
        """Sweep the torso and beak relative to the turtle over this update.

        Source art spans x=239..392 for the body/head and 392..410 for the beak
        on a 600-wide canvas, rendered to 120 pixels at a 21.25px/unit reference.
        Wings are deliberately excluded from these narrow central capsules.
        """
        now=self.position();old=self.previous_position
        relative_start=(previous[0]-old[0],previous[1]-old[1])
        relative_end=(current[0]-now[0],current[1]-now[1])
        previous_angle=angle if previous_angle is None else previous_angle
        heading=(math.cos(math.radians(angle)),math.sin(math.radians(angle)))
        old_heading=(math.cos(math.radians(previous_angle)),math.sin(math.radians(previous_angle)))
        # Body, head and tail follow the turtle's heading; a beak touching its
        # extended head must count even before the centre circles overlap.
        extension=max(0.0,1.0-tuck)
        turtle_parts=((0.0,TURTLE_RADIUS),(.56*OBJECT_SCALE*extension,.24*OBJECT_SCALE*extension),(-.70*OBJECT_SCALE*extension,.13*OBJECT_SCALE*extension))
        for direction in set((self.previous_direction,self.direction)):
            vx,vy=self.line.dx*direction,self.line.dy*direction
            for lo,hi,radius in ((-.55,.78,.24),(.78,22/(850/40),.09)):
                a=(vx*lo*self.size_factor,vy*lo*self.size_factor)
                b=(vx*hi*self.size_factor,vy*hi*self.size_factor)
                for offset,turtle_radius in turtle_parts:
                    start=(relative_start[0]+old_heading[0]*offset,relative_start[1]+old_heading[1]*offset)
                    end=(relative_end[0]+heading[0]*offset,relative_end[1]+heading[1]*offset)
                    if segment_distance(start,end,a,b)<=turtle_radius+radius*self.size_factor:return True
        return False

    def make_surface(self, phase=0.0):
        """Procedural dorsal hawk: layered primaries, broad wings and fanned tail."""
        resolution=2
        surf=pygame.Surface((600*resolution,500*resolution),pygame.SRCALPHA)
        colour_cache={}
        def colour(c):
            if self.kind=="brown" or c in ((168,145,88),(45,41,34),(185,146,58),(19,19,15)):return c
            if c not in colour_cache:
                v=.30*c[0]+.59*c[1]+.11*c[2]
                if self.kind=="black":result=(v*.52,v*.55,v*.63)
                elif self.kind=="white":result=(142+v*.58,147+v*.58,147+v*.55)
                else:result=(43+v*1.13,10+v*.38,14+v*.29)
                colour_cache[c]=tuple(max(0,min(255,round(x))) for x in result)
            return colour_cache[c]
        def poly(col,pts):
            pygame.draw.polygon(surf,colour(col),[(round(x*resolution),round(y*resolution)) for x,y in pts])
        def line(col,pts,w=1):
            pygame.draw.lines(surf,colour(col),False,[(round(x*resolution),round(y*resolution)) for x,y in pts],max(1,round(w*resolution)))
        def ell(col,r):
            x,y,right,bottom=r
            pygame.draw.ellipse(surf,colour(col),(round(x*resolution),round(y*resolution),round((right-x)*resolution),round((bottom-y)*resolution)))
        def bez(a,b,c,e,n=12):
            return [tuple((1-t)**3*a[j]+3*(1-t)**2*t*b[j]+3*(1-t)*t*t*c[j]+t**3*e[j] for j in (0,1)) for t in [i/n for i in range(n+1)]]
        for i in range(9):
            root=(255,250);tip=(159+abs(i-4)*3,217+i*8)
            dx,dy=tip[0]-root[0],tip[1]-root[1];length=math.hypot(dx,dy);nx,ny=-dy/length,dx/length
            shape=bez((root[0]+nx*4,root[1]+ny*4),(214+nx*8,250+ny*8),(tip[0]+nx*8,tip[1]+ny*8),tip)+bez(tip,(tip[0]-nx*8,tip[1]-ny*8),(214-nx*8,250-ny*8),(root[0]-nx*4,root[1]-ny*4))
            poly((74,53,42),shape)
            line((151,112,75),[(tip[0]+10,tip[1]),(226,249)],1.3)
            for f in (.25,.46):
                cx=root[0]+dx*(1-f);cy=root[1]+dy*(1-f)
                line((183,149,104),[(cx+nx*5,cy+ny*5),(cx-nx*5,cy-ny*5)],2)
        # One projected contraction/recovery per counted beat. Previously signed
        # angles produced TWO apparent beats per cycle when viewed from above.
        theta=phase+.16*math.sin(phase)
        stroke=.5-.5*math.cos(theta)
        arm=1.12*stroke
        wrist=1.03*(.5-.5*math.cos(theta-.16))
        fold=.28*stroke
        for side in (-1,1):
            def tr(p):
                x,y=p;dist=max(0,250-y)
                outer=max(0,min(1,(dist-65)/115))
                # Straighten the swept-back outline, then flex at the wrist.
                x+=dist*.33
                x=312+(x-312)*(1-fold*.22)-fold*outer*36
                inner=min(dist,92)*math.cos(arm)
                outer_span=max(0,dist-92)*math.cos(wrist)*(1-fold*.15)
                height=min(dist,92)*math.sin(arm)+max(0,dist-92)*math.sin(wrist)
                return x,250+side*(inner+outer_span)+height*.13
            def shade(c):
                light=round(-7*math.sin(arm)+4*fold)
                return tuple(max(0,min(255,v+light)) for v in c)
            def wp(c,p):poly(shade(c),[tr(q) for q in p])
            def wl(c,p,w=1):line(shade(c),[tr(q) for q in p],w)
            # A continuous wrist fan joins the primaries to the secondaries.
            # Only the outer parts of the seven long feathers separate into fingers.
            contour=bez((330,241),(344,176),(320,120),(285,95))
            contour+=bez((285,95),(281,73),(278,58),(275,52))[1:]
            contour+=bez((275,52),(256,46),(231,61),(211,82))[1:]
            contour+=bez((211,82),(195,98),(184,111),(174,123))[1:]
            contour+=bez((174,123),(194,151),(221,189),(244,212))[1:]
            contour+=bez((244,212),(260,241),(292,253),(330,241))[1:]
            wp((99,71,46),contour)
            feathers=[]
            for j in range(10):
                f=j/9;feathers.append(((308-36*f,207-91*f),(244-69*f,212-88*f),10))
            for j,tip in enumerate([(270,15),(247,14),(224,25),(203,43),(185,68),(172,95),(165,122)]):
                feathers.append(((284-j*3,111-j*1.5),tip,15.0))
            for k,(root,tip,width) in enumerate(feathers):
                dx,dy=tip[0]-root[0],tip[1]-root[1];length=math.hypot(dx,dy);n=(-dy/length,dx/length)
                a=(root[0]+n[0]*width*.55,root[1]+n[1]*width*.55)
                b=(root[0]-n[0]*width*.55,root[1]-n[1]*width*.55)
                # Long tapered, almost triangular fingers with a slight curved edge.
                p=bez(a,(root[0]+dx*.45+n[0]*width,root[1]+dy*.45+n[1]*width),(tip[0]+n[0]*width*.18,tip[1]+n[1]*width*.18),tip)
                p+=bez(tip,(tip[0]-n[0]*width*.12,tip[1]-n[1]*width*.12),(root[0]+dx*.5-n[0]*width*.6,root[1]+dy*.5-n[1]*width*.6),b)
                wp((64,48,39),p)
                center=(root[0]+dx*.45,root[1]+dy*.45)
                wp((109+k%3*6,79+k%3*4,51+k%3*3),[(center[0]+(x-center[0])*.92,center[1]+(y-center[1])*.98) for x,y in p])
                # A soft highlight stops well before the tip; no stripe across the wings.
                if k%2==0:
                    wl((155,116,72),[root,(root[0]+dx*.52,root[1]+dy*.52)],.8)
            cap=bez((326,240),(337,175),(298,115),(267,98))+bez((267,98),(256,139),(258,195),(283,235))+bez((283,235),(300,245),(315,247),(326,240))
            wp((112,82,54),cap)
            for row in range(4):
                for j in range(9):
                    x=282+row*8-j*2.4;y=220-j*12-row*4
                    p=bez((x-5,y+6),(x-10,y),(x-3,y-10),(x+3,y-12))+bez((x+3,y-12),(x+9,y-3),(x+6,y+4),(x-5,y+6))
                    wp((133+row*4,102+row*3,68+row*3),p)
                    wl((173,141,96),p[:12],.65)
        ell((65,48,37),(239,220,366,280));ell((106,77,48),(246,224,362,275))
        for j in range(8):
            x=260+j*10
            line((142,108,69),bez((x,231),(x+12,239),(x+12,259),(x,269)),1.2)
        ell((76,56,40),(345,232,392,269));ell((102,75,47),(351,234,389,265))
        poly((168,145,88),[(386,241),(404,246),(398,253),(390,251)])
        poly((45,41,34),[(400,245),(410,250),(403,256),(404,251),(398,250)])
        for y in (240,259):
            ell((185,146,58),(379,y-2,385,y+2));ell((19,19,15),(382,y-1,385,y+1))
        # Torso stays centred in every pose and when the bird changes direction.
        return pygame.transform.smoothscale(surf,(round(120*self.size_factor),round(100*self.size_factor)))

    def rendered_art(self):
        vx, vy = self.line.dx*self.direction, self.line.dy*self.direction
        angle = math.degrees(math.atan2(vy, vx))
        zoom = SCALE/(850/40)
        key = (id(self.sprite), id(self.shadow), angle, zoom)
        if getattr(self, "_render_key", None) != key:
            self._render_pair = (pygame.transform.rotozoom(self.sprite, angle, zoom),
                                 pygame.transform.rotozoom(self.shadow, angle, zoom))
            self._render_key = key
        return self._render_pair

    def draw(self):
        sx, sy = graph_to_screen(*self.position())
        image, _ = self.rendered_art()
        SCREEN.blit(image, image.get_rect(center=(sx, sy)))

    def draw_shadow(self):
        sx, sy = graph_to_screen(*self.position())
        _, shadow = self.rendered_art()
        rect = shadow.get_rect(center=(sx+12, sy+17))
        SCREEN.blit(shadow, rect)
        return rect


def make_sand(seed=42):
    SIZE = 850
    rng = random.Random(seed)
    sand = pygame.Surface((SIZE, SIZE)).convert()
    # Several scales of smooth random variation give sand depth and uneven colour.
    sand.fill((222, 196, 146))
    for cells, strength in ((9, 24), (35, 12), (125, 7)):
        noise = pygame.Surface((cells, cells))
        for y in range(cells):
            for x in range(cells):
                v = rng.randrange(128 - strength, 129 + strength)
                noise.set_at((x, y), (max(0, min(255, 222 + v - 128)),
                                         max(0, min(255, 196 + v - 128)),
                                         max(0, min(255, 146 + v - 128))))
        noise = pygame.transform.smoothscale(noise, (SIZE, SIZE))
        noise.set_alpha(100)
        sand.blit(noise, (0, 0))
    # Long, uneven wind ripples: broad soft shadows with thin sunlit crests.
    ripple = pygame.Surface((SIZE, SIZE), pygame.SRCALPHA)
    for row in range(-5, 35):
        base = row * 31 + rng.uniform(-7, 7)
        phase = rng.uniform(-.3, .3)
        points = []
        for x in range(-10, SIZE + 11, 4):
            y = base + 13 * math.sin(x / 115 + row * .25 + phase) + .105 * x
            y += 3 * math.sin(x / 43 + row * .6)
            points.append((x, round(y)))
        for offset, width, colour in ((8, 13, (100, 64, 27, 8)),
                                      (5, 8, (119, 80, 36, 13)),
                                      (2, 4, (139, 98, 43, 18)),
                                      (-1, 2, (255, 244, 205, 44))):
            pygame.draw.lines(ripple, colour, False,
                              [(x, y + offset) for x, y in points], width)
    sand.blit(ripple, (0, 0))
    # Fine mineral grains: several tones, mostly tiny and low contrast.
    colours = ((201, 173, 123), (233, 211, 169), (242, 223, 186),
               (213, 185, 136), (225, 199, 152), (193, 164, 115))
    sand.lock()
    for _ in range(175000):
        x, y = rng.randrange(SIZE), rng.randrange(SIZE)
        old = sand.get_at((x, y))
        c = rng.choice(colours)
        sand.set_at((x, y), tuple((old[i] * 2 + c[i]) // 3 for i in range(3)))
    sand.unlock()
    # Sparse tiny shell chips and pits, with a bright lip and a little shadow.
    for _ in range(380):
        x, y = rng.randrange(SIZE), rng.randrange(SIZE)
        radius = rng.choice((1, 1, 1, 2))
        pygame.draw.circle(sand, (181, 151, 104), (x + 1, y + 1), radius)
        pygame.draw.circle(sand, rng.choice(((239, 222, 188), (214, 188, 146),
                                            (246, 230, 199))), (x, y), radius)
    return sand

def soft_ellipse(s, rect, colour, alpha=50):
    layer = pygame.Surface(s.get_size(), pygame.SRCALPHA)
    pygame.draw.ellipse(layer, (*colour, alpha), rect)
    w, h = s.get_size()
    layer = pygame.transform.smoothscale(pygame.transform.smoothscale(layer, (w//6,h//6)), (w,h))
    s.blit(layer,(0,0))

def smooth_curve(points, steps=12, closed=True):
    result=[]
    size=len(points)
    count=size if closed else size-1
    for i in range(count):
        p0=points[(i-1)%size] if closed or i>0 else points[0]
        p1=points[i];p2=points[(i+1)%size]
        p3=points[(i+2)%size] if closed or i+2<size else points[-1]
        for j in range(steps):
            t=j/steps;t2=t*t;t3=t2*t
            result.append(tuple(.5*((2*p1[k])+(-p0[k]+p2[k])*t+
                               (2*p0[k]-5*p1[k]+4*p2[k]-p3[k])*t2+
                               (-p0[k]+3*p1[k]-3*p2[k]+p3[k])*t3) for k in (0,1)))
    return result

def improved_bucket(s,rng):
    # Handle-free blue pail, one material with a smooth cylindrical light gradient.
    for x in range(137,244):
        f=(x-137)/106
        half=49-14*f
        for y in range(round(164-half),round(164+half)+1):
            h=(y-(164-half))/(2*half)
            light=.66+.34*math.sin(h*math.pi)+.07*(1-f)
            s.set_at((x,y),tuple(min(255,round(c*light)) for c in (55,156,187)))
    pygame.draw.ellipse(s,(36,111,139),(230,130,22,69))
    pygame.draw.arc(s,(82,175,196),(231,131,19,66),-1.4,1.4,2)
    pygame.draw.ellipse(s,(105,193,211),(121,111,34,105))
    pygame.draw.ellipse(s,(24,77,98),(127,118,24,91))
    pygame.draw.ellipse(s,(29,94,115),(132,123,15,80))
    pygame.draw.arc(s,(163,221,228),(122,112,33,102),1.7,4.6,3)
    pygame.draw.aaline(s,(97,189,210),(155,122),(229,135))

def improved_seaweed(s,rng):
    # Broad, curved kelp ribbons, with shaded undersides and bright folded ridges.
    for i in range(19):
        root=pygame.Vector2(rng.uniform(160,198),rng.uniform(174,193))
        angle=rng.uniform(-3.05,-.08);length=rng.uniform(40,101)
        pts=[];normals=[]
        for j in range(29):
            t=j/28
            x=root.x+math.cos(angle)*length*t+math.sin(t*7+i)*8*t
            y=root.y+math.sin(angle)*length*t+math.cos(t*8+i)*6*t
            pts.append((x,y))
        for j in range(len(pts)):
            prev=pygame.Vector2(pts[max(0,j-1)]);nxt=pygame.Vector2(pts[min(len(pts)-1,j+1)])
            tangent=nxt-prev
            normal=pygame.Vector2(-tangent.y,tangent.x).normalize() if tangent.length_squared() else pygame.Vector2(1,0)
            normals.append(normal)
        width=rng.uniform(4,7)
        left=[];right=[]
        for j,(point,normal) in enumerate(zip(pts,normals)):
            t=j/28;w=width*(.25+.75*math.sin(math.pi*(t*.85+.08)))
            left.append(tuple(pygame.Vector2(point)+normal*w))
            right.append(tuple(pygame.Vector2(point)-normal*w))
        colour=rng.choice(((66,94,48),(76,102,47),(92,109,47),(80,111,58)))
        pygame.draw.polygon(s,tuple(max(0,c-17) for c in colour),[(x+2,y+2) for x,y in left+right[::-1]])
        pygame.draw.polygon(s,colour,left+right[::-1])
        # Highlight follows a fold, rather than outlining every strand.
        ridge=[(round((pts[j][0]*2+left[j][0])/3),round((pts[j][1]*2+left[j][1])/3)) for j in range(3,26)]
        pygame.draw.lines(s,tuple(c+24 for c in colour),False,ridge,2)
        pygame.draw.aalines(s,tuple(c+36 for c in colour),False,ridge[3:16])

def hat(s,rng):
    # Broad straw brim with concentric woven rings.
    for k in range(82,0,-1):
        shade=round(213+(82-k)*.25)
        pygame.draw.ellipse(s,(shade,shade-28,shade-80),(180-k,165-round(k*.62),2*k,round(k*1.24)))
    for k in range(35,82,3):
        pygame.draw.ellipse(s,(187,155,98),(180-k,165-round(k*.62),2*k,round(k*1.24)),1)
    for i in range(65):
        t=i*math.tau/65
        pygame.draw.aaline(s,(222,190,131),(round(180+44*math.cos(t)),round(165+28*math.sin(t))),
                           (round(180+80*math.cos(t)),round(165+49*math.sin(t))))
    pygame.draw.ellipse(s,(113,86,48),(137,134,87,57))
    for k in range(40,0,-1):
        v=(40-k)/40
        pygame.draw.ellipse(s,(round(208+26*v),round(179+25*v),round(120+27*v)),
                            (180-k,153-round(k*.64),2*k,round(k*1.28)))
    pygame.draw.arc(s,(47,94,108),(139,127,82,55),3.15,6.2,8)
    pygame.draw.arc(s,(85,137,145),(139,125,82,55),3.2,6.05,2)

def flipflops(s,rng):
    scale=3
    for cx,cy,angle in ((145,161,15),(218,171,-14)):
        item=pygame.Surface((72*scale,142*scale),pygame.SRCALPHA)
        shape=smooth_curve([(17,11),(31,6),(46,10),(56,24),(57,43),(51,66),
                            (49,85),(49,110),(43,126),(32,130),(21,125),(15,111),(16,87),(12,65),(9,45),(10,27)])
        pts=[(round(x*scale),round(y*scale)) for x,y in shape]
        pygame.draw.polygon(item,(31,73,86),[(x+scale,y+3*scale) for x,y in pts])
        pygame.draw.polygon(item,(57,142,161),pts)
        pygame.draw.lines(item,(112,187,194),True,pts,2)
        mask=pygame.Surface(item.get_size(),pygame.SRCALPHA)
        for y in range(28,120,6):
            pygame.draw.line(mask,(72,155,173),(9*scale,y*scale),(57*scale,y*scale),scale)
        clip=pygame.Surface(item.get_size(),pygame.SRCALPHA);pygame.draw.polygon(clip,(255,255,255),pts)
        mask.blit(clip,(0,0),special_flags=pygame.BLEND_RGBA_MULT);item.blit(mask,(0,0))
        strap=[(14,65),(23,49),(32,35),(43,48),(52,63)]
        for dy,c,w in ((3,(29,67,77),9),(0,(229,154,78),7)):
            pygame.draw.lines(item,c,False,[(x*scale,(y+dy)*scale) for x,y in strap],w*scale)
        pygame.draw.lines(item,(255,209,145),False,[(x*scale,(y-2)*scale) for x,y in strap],scale)
        pygame.draw.circle(item,(198,117,52),(32*scale,35*scale),3*scale)
        image=pygame.transform.smoothscale(item,(72,142));image=pygame.transform.rotozoom(image,angle,1)
        s.blit(image,image.get_rect(center=(cx,cy)))

def surfboard(s,rng,angle=-17):
    # Smooth parallel-sided longboard viewed flat from above.
    scale=3;item=pygame.Surface((110*scale,235*scale),pygame.SRCALPHA)
    outline=smooth_curve([(55,8),(74,14),(88,36),(92,75),(92,157),(85,202),
                           (72,220),(55,225),(38,220),(25,202),(18,157),(18,75),(22,36),(36,14)])
    pts=[(round(x*scale),round(y*scale)) for x,y in outline]
    pygame.draw.polygon(item,(235,235,215),pts)
    mask=pygame.mask.from_surface(item)
    for y in range(8*scale,226*scale):
        for x in range(17*scale,94*scale):
            if mask.get_at((x,y)):
                xx=x/scale;yy=y/scale
                c=(239,237,218)
                if 43<xx<67:c=(43,151,172)
                if 51<xx<58:c=(238,154,68)
                edge=min(abs(xx-18),abs(92-xx))
                f=.94+.06*min(1,edge/8)
                item.set_at((x,y),(*[round(v*f) for v in c],255))
    pygame.draw.lines(item,(146,175,168),True,pts,2)
    pass  # No white highlight across the surfboard.
    pygame.draw.circle(item,(56,88,91),(55*scale,208*scale),3*scale)
    item=pygame.transform.smoothscale(item,(110,235))
    item=pygame.transform.rotozoom(item,angle,1)
    s.blit(item,item.get_rect(center=(180,163)))

def parasol(s,rng):
    scale=3;item=pygame.Surface((270*scale,100*scale),pygame.SRCALPHA)
    def pts(points):return [(round(x*scale),round(y*scale)) for x,y in points]
    # Neat capped pole and a closed canopy gathered into rounded fabric folds.
    pygame.draw.line(item,(145,121,79),(15*scale,50*scale),(254*scale,50*scale),4*scale)
    pygame.draw.line(item,(224,208,170),(15*scale,49*scale),(254*scale,49*scale),scale)
    pygame.draw.circle(item,(100,78,46),(255*scale,50*scale),3*scale)
    colours=((36,119,143),(61,159,171),(226,228,199),(238,200,110),(46,137,154))
    for i,c in enumerate(colours):
        start=-math.pi/2+i*math.pi/5
        end=-math.pi/2+(i+1)*math.pi/5
        arc=[(205+14*math.cos(start+(end-start)*j/12),
              50+28*math.sin(start+(end-start)*j/12)) for j in range(13)]
        pygame.draw.polygon(item,c,pts([(40,50)]+arc))
        pygame.draw.line(item,tuple(max(0,v-24) for v in c),(41*scale,50*scale),
                         (round(arc[-1][0]*scale),round(arc[-1][1]*scale)),scale)
    pygame.draw.rect(item,(192,166,116),(160*scale,29*scale,5*scale,40*scale),border_radius=2*scale)
    pygame.draw.line(item,(243,224,183),(161*scale,31*scale),(161*scale,66*scale),scale)
    pygame.draw.circle(item,(174,147,98),(39*scale,50*scale),3*scale)
    item=pygame.transform.smoothscale(item,(270,100))
    item=pygame.transform.rotozoom(item,24,1)
    s.blit(item,item.get_rect(center=(180,163)))

def conch(s,rng):
    scale=3;item=pygame.Surface((230*scale,160*scale),pygame.SRCALPHA)
    def scaled(points):return [(round(x*scale),round(y*scale)) for x,y in points]
    # Rounded whorls spiral into a flared outer lip and tapered siphonal canal.
    contour=smooth_curve([(23,75),(39,57),(58,43),(84,35),(113,42),(138,60),(151,84),
                           (173,99),(208,122),(216,135),(190,131),(165,120),(145,112),
                           (117,117),(88,110),(66,100),(44,91)])
    pygame.draw.polygon(item,(235,232,220),scaled(contour))
    for cx,cy,rx,ry in ((111,80,46,39),(82,68,33,30),(58,68,23,23),(39,74,16,15)):
        for radius in range(rx*scale,0,-1):
            v=1-radius/(rx*scale)
            c=(round(231+22*v),round(228+23*v),round(216+29*v))
            rect=(round(cx*scale-radius),round(cy*scale-radius*ry/rx),radius*2,max(1,round(radius*2*ry/rx)))
            pygame.draw.ellipse(item,c,rect)
        pygame.draw.arc(item,(198,194,179),((cx-rx)*scale,(cy-ry)*scale,rx*2*scale,ry*2*scale),-.9,1.5,scale)
    pygame.draw.polygon(item,(247,244,232),scaled(smooth_curve([(21,77),(31,66),(43,72),(37,84)])))
    # Rounded shoulder nodules instead of hard triangular spikes.
    for x,y in ((72,43),(92,37),(116,45),(135,61)):
        pygame.draw.ellipse(item,(232,228,212),((x-5)*scale,(y-8)*scale,13*scale,17*scale))
        pygame.draw.arc(item,(255,254,245),((x-5)*scale,(y-8)*scale,13*scale,17*scale),1.3,3.8,scale)
    lip=smooth_curve([(136,62),(153,69),(159,87),(180,103),(209,122),(216,133),
                      (195,127),(170,115),(146,109),(131,94)])
    pygame.draw.polygon(item,(250,247,235),scaled(lip))
    opening=pygame.Rect(132*scale,70*scale,25*scale,37*scale)
    pygame.draw.lines(item,(255,255,247),False,scaled(smooth_curve([(155,91),(174,106),(198,119),(211,129)],closed=False)),2*scale)
    for j in range(5):
        pygame.draw.arc(item,(214,210,193),((83+j*6)*scale,(54+j*2)*scale,47*scale,48*scale),-.9,1.1,scale)
    image=pygame.transform.smoothscale(item,(230,160));image=pygame.transform.rotozoom(image,-9,1)
    s.blit(image,image.get_rect(center=(180,163)))

def bottle(s,rng):
    item=pygame.Surface((95,210),pygame.SRCALPHA)
    # Capped reusable water bottle lying on the beach, with moulded shoulders.
    pts=[(32,26),(63,26),(63,47),(75,62),(79,77),(79,178),(71,190),(24,190),
         (16,178),(16,77),(20,62),(32,47)]
    pygame.draw.polygon(item,(39,102,100),pts)
    mask=pygame.mask.from_surface(item)
    for y in range(30,190):
        for x in range(16,80):
            if mask.get_at((x,y)):
                shade=.62+.37*math.sin((x-16)/64*math.pi)
                item.set_at((x,y),(round(73*shade),round(159*shade),round(151*shade),255))
    for y in (77,87,166,176):pygame.draw.line(item,(62,133,130),(19,y),(76,y),2)
    pygame.draw.rect(item,(46,76,80),(29,13,37,25),border_radius=5)
    for x in range(32,64,5):pygame.draw.line(item,(78,110,111),(x,17),(x,33),1)
    pygame.draw.line(item,(149,206,189),(23,78),(23,97),3)
    image=pygame.transform.rotate(item,-36)
    s.blit(image,image.get_rect(center=(180,163)))

def starfish(s,rng):
    cx,cy=180,165
    vertices=[]
    for i in range(10):
        angle=-math.pi/2+i*math.pi/5
        r=78 if i%2==0 else 28
        vertices.append((cx+math.cos(angle)*r,cy+math.sin(angle)*r))
    outline=smooth_curve(vertices,steps=16)
    mask_s=pygame.Surface(s.get_size(),pygame.SRCALPHA);pygame.draw.polygon(mask_s,(255,255,255),outline)
    mask=pygame.mask.from_surface(mask_s)
    for y in range(78,250):
        for x in range(94,267):
            if mask.get_at((x,y)):
                dx,dy=x-cx,y-cy
                radial=math.hypot(dx,dy)
                theta=math.atan2(dy,dx)+math.pi/2
                ridge=math.cos(theta*5)
                light=13*ridge-10*dx/78-13*dy/78+6*(1-radial/90)+rng.uniform(-2,2)
                s.set_at((x,y),tuple(max(0,min(255,round(v+light))) for v in (218,138,78)))
    # Rows of small pale ossicles make the skin recognisably textured.
    for arm in range(5):
        t=-math.pi/2+arm*math.tau/5
        direction=pygame.Vector2(math.cos(t),math.sin(t));side=pygame.Vector2(-direction.y,direction.x)
        for r in range(13,72,7):
            for sign in (-1,0,1):
                width=9*(1-r/82)
                point=pygame.Vector2(cx,cy)+direction*r+side*sign*width
                x,y=round(point.x),round(point.y)
                pygame.draw.circle(s,(178,108,61),(x+1,y+1),2)
                pygame.draw.circle(s,(239,179,112),(x,y),2)
                pygame.draw.circle(s,(250,201,139),(x,y-1),1)
    pygame.draw.circle(s,(235,168,100),(cx,cy),4)

def beach_ball(s,rng):
    cx,cy,r=180,163,73
    colours=((248,246,229),(229,51,48),(246,134,37),(248,212,46),(42,129,218),(56,170,91))
    for y in range(cy-r,cy+r+1):
        for x in range(cx-r,cx+r+1):
            nx,ny=(x-cx)/r,(y-cy)/r
            rr=nx*nx+ny*ny
            if rr<=1:
                z=math.sqrt(max(0,1-rr))
                panel=((math.atan2(ny+.18,nx+.12)+math.tau)%math.tau)/math.tau*6
                base=colours[int(panel)%6]
                light=.58+.42*max(0,-.36*nx-.42*ny+.83*z)
                if min(panel%1,1-panel%1)<.007:base=(238,234,218)
                gloss=max(0,1-((nx+.34)**2+(ny+.38)**2)/.11)**3*.58
                colour=tuple(min(255,round(c*light+(255-c*light)*gloss)) for c in base)
                s.set_at((x,y),colour)
    pygame.draw.circle(s,(238,234,218),(round(cx-r*.12),round(cy-r*.18)),5)
    pygame.draw.circle(s,(253,251,237),(round(cx-r*.12)-1,round(cy-r*.18)-1),3)

# -------------------- GAME --------------------
def towel(s,rng):
    """An empty, striped beach towel with a soft fabric edge."""
    item=pygame.Surface((150,270),pygame.SRCALPHA)
    colour=rng.choice(((57,151,176),(224,116,91),(116,148,187)))
    pygame.draw.rect(item,colour,(17,9,116,252),border_radius=9)
    for y in range(20,255,28):pygame.draw.rect(item,(241,232,203),(20,y,110,8))
    pygame.draw.line(item,tuple(max(0,c-20) for c in colour),(21,254),(128,254),2)
    item=pygame.transform.rotozoom(item,rng.choice((-14,12)),1)
    s.blit(item,item.get_rect(center=(180,174)))


def festival_board(s,rng,angle=0,variant=None):
    """Bright shoreline boards with distinct geometric paintwork."""
    scale=3;item=pygame.Surface((110*scale,235*scale),pygame.SRCALPHA)
    outline=smooth_curve([(55,6),(77,16),(91,49),(93,158),(83,207),(66,226),
                          (55,229),(44,226),(27,207),(17,158),(19,49),(33,16)])
    pts=[(round(x*scale),round(y*scale)) for x,y in outline]
    mask=pygame.Surface(item.get_size(),pygame.SRCALPHA);pygame.draw.polygon(mask,WHITE,pts)
    palettes=(((239,87,94),(252,184,63),(45,164,183),(55,84,157)),
                        ((109,75,172),(243,121,72),(250,216,91),(47,172,146)),
                        ((37,153,191),(247,123,139),(250,220,113),(82,79,164)))
    colours=palettes[rng.randrange(3) if variant is None else variant%3]
    item.fill((*colours[0],255))
    for i in range(1,7):
        y=(i*38-35)*scale
        pygame.draw.polygon(item,colours[i%4],[(0,y),(110*scale,y+39*scale),(110*scale,y+76*scale),(0,y+37*scale)])
        pygame.draw.line(item,(251,243,217),(0,y),(110*scale,y+39*scale),3*scale)
    item.blit(mask,(0,0),special_flags=pygame.BLEND_RGBA_MULT)
    pygame.draw.lines(item,(247,241,217),True,pts,2*scale)
    pygame.draw.circle(item,(35,68,90),(55*scale,211*scale),3*scale)
    item=pygame.transform.smoothscale(item,(110,235));item=pygame.transform.rotozoom(item,angle,1)
    s.blit(item,item.get_rect(center=(180,163)))


def grounded_prop(painter):
    """Apply one close, soft silhouette shadow after all rotations are complete."""
    def draw(surface,*args,**kwargs):
        item=pygame.Surface(surface.get_size(),pygame.SRCALPHA)
        painter(item,*args,**kwargs)
        shadow=make_ground_shadow(item,opacity=46,softness=3)
        # The padding is part of the blur, not an additional positional offset.
        surface.blit(shadow,(5-6,7-6))
        surface.blit(item,(0,0))
    return draw


improved_bucket,improved_seaweed,hat,flipflops,surfboard,parasol,conch,bottle,starfish,beach_ball,towel,festival_board=(
    grounded_prop(painter) for painter in
    (improved_bucket,improved_seaweed,hat,flipflops,surfboard,parasol,conch,bottle,starfish,beach_ball,towel,festival_board))


def story_ellipse(surface, colour, rect):
    """Antialiased filled story_ellipse."""
    rect = pygame.Rect(rect)
    # Supersampling avoids speckled alpha edges on the translucent head layer.
    tile = pygame.Surface((max(2,rect.width*2),max(2,rect.height*2)),pygame.SRCALPHA)
    pygame.draw.ellipse(tile,colour,tile.get_rect())
    tile = pygame.transform.smoothscale(tile,(max(1,rect.width),max(1,rect.height)))
    surface.blit(tile,rect.topleft)

def story_curve(points, steps=12, closed=True):
    """Smooth rounded outlines for the flippers and eggshell."""
    result = []
    for i in range(len(points) if closed else len(points) - 1):
        a = points[(i - 1) % len(points)] if closed or i else points[0]
        b, c = points[i], points[(i + 1) % len(points)]
        d = points[(i + 2) % len(points)] if closed or i + 2 < len(points) else points[-1]
        for j in range(steps):
            t = j / steps
            result.append(tuple(round(.5 * (2*b[k] + (-a[k]+c[k])*t +
                (2*a[k]-5*b[k]+4*c[k]-d[k])*t*t +
                (-a[k]+3*b[k]-3*c[k]+d[k])*t*t*t)) for k in (0, 1)))
    return result

def story_shape(surface, colour, points):
    points = story_curve(points)
    left = min(x for x,y in points)-2
    top = min(y for x,y in points)-2
    width = max(x for x,y in points)-left+3
    height = max(y for x,y in points)-top+3
    tile = pygame.Surface((width*2,height*2),pygame.SRCALPHA)
    pygame.draw.polygon(tile,colour,[((x-left)*2,(y-top)*2) for x,y in points])
    tile = pygame.transform.smoothscale(tile,(width,height))
    surface.blit(tile,(left,top))

def story_nest_and_egg(surface):
    story_ellipse(surface,(218,193,149),(278,449,432,100))
    story_ellipse(surface,(228,206,167),(293,459,397,74))
    # Empty broken egg beside the hatchling, with a dark interior and a pale lip.
    egg = [(310,419),(327,437),(344,416),(360,436),(378,417),
           (397,436),(416,419),(437,430),(435,471),(414,501),
           (381,515),(345,509),(319,488),(309,456)]
    story_ellipse(surface,(196,175,133),(302,448,144,62))
    story_shape(surface,(238,230,203),egg)
    pygame.draw.lines(surface,(255,249,225),False,egg[:8],4)
    pygame.draw.arc(surface,(214,202,171),(318,441,109,61),math.pi,math.tau,2)
    for fragment in ([(284,500),(298,476),(307,504)],
                     [(437,508),(451,489),(465,511)],
                     [(321,535),(337,520),(347,537)]):
        pygame.draw.polygon(surface,(248,241,216),fragment)
        pygame.draw.aalines(surface,(220,207,173),True,fragment)

def story_glance(time):
    """Look left, pause, look right, and briefly face the person helping."""
    keys = [(0,-.8),(1.5,-.8),(2.7,.8),(4.2,.8),(5.4,0),(6.8,0),(8,-.8)]
    phase = time % 8
    for (a,x),(b,y) in zip(keys,keys[1:]):
        if a <= phase <= b:
            u = (1-math.cos(math.pi*(phase-a)/(b-a)))/2
            return x+(y-x)*u
    return 0

def story_draw_hatchling(surface, time, happy=False, swimming=False):
    look = math.sin(time*.7)*.18 if happy else story_glance(time)
    breath = math.sin(time*2.4)*1.4
    # A small grounded shadow: this hatchling is sitting uncertainly by its egg.
    if not swimming:
        shadow = pygame.Surface((190,54),pygame.SRCALPHA)
        story_ellipse(shadow,(91,71,41,28),(8,6,173,40))
        shadow = pygame.transform.smoothscale(pygame.transform.smoothscale(shadow,(48,14)),shadow.get_size())
        surface.blit(shadow,(428,486))
    # Hind flippers and a tiny tail.
    story_shape(surface,(71,137,99),[(493,485),(469,502),(449,514),(455,521),(485,516),(507,502)])
    story_shape(surface,(76,143,103),[(546,488),(560,501),(581,514),(574,521),(547,513),(533,501)])
    story_shape(surface,(74,135,95),[(516,493),(527,518),(538,494)])
    # Only the rim of the back shell peeks around the sides of the torso.
    story_ellipse(surface,(50,104,79),(462,386+breath,113,125))
    story_ellipse(surface,(106,153,91),(467,389+breath,103,116))
    story_ellipse(surface,(83,154,107),(477,395+breath,87,111))
    # A warm, flatter belly; gentle horizontal folds rather than back-shell scutes.
    story_ellipse(surface,(190,195,128),(489,413+breath,63,84))
    story_ellipse(surface,(219,218,158),(492,416+breath,56,76))
    story_ellipse(surface,(229,226,172),(497,420+breath,44,64))
    for y,w in ((438,40),(454,46),(470,40)):
        pygame.draw.arc(surface,(188,190,126),(520-w/2,y+breath,w,11),math.pi,math.tau,1)
    # One flipper braces on the sand; the other lifts slightly, as if asking for help.
    if swimming:
        paddle=math.sin(time*3.4)*14
        story_shape(surface,(65,132,94),[(487,412),(466,416),(430,427+paddle),(421,441+paddle),(448,454+paddle),(482,440),(496,431)])
        story_shape(surface,(81,151,105),[(548,413),(567,414),(600,427-paddle),(610,441-paddle),(587,454-paddle),(555,440)])
        pygame.draw.aaline(surface,(126,177,118),(571,425-paddle),(598,437-paddle))
    else:
        story_shape(surface,(65,132,94),[(487,412),(462,429),(437,460),(428,480),(443,481),(476,456),(496,431)])
        lift = math.sin(time*1.5)*3
        story_shape(surface,(81,151,105),[(548,413),(567,402+lift),(591,393+lift),(601,401+lift),(587,422),(560,440)])
        pygame.draw.aaline(surface,(126,177,118),(569,409+lift),(590,401+lift))
    story_ellipse(surface,(85,154,108),(494,371+breath,53,54))
    # Oversized head on its own surface, allowing a small curious/worried tilt.
    head = pygame.Surface((190,170),pygame.SRCALPHA)
    story_ellipse(head,(55,117,86),(24,22,143,123))
    story_ellipse(head,(91,165,114),(27,23,137,115))
    story_ellipse(head,(111,181,126),(36,25,117,66))
    story_ellipse(head,(117,182,125),(45,93,103,42))
    blink_phase = time % 5.1
    blink = max(0,1-abs(blink_phase-4.65)/.12)
    for x in (62,127):
        story_ellipse(head,(63,122,88),(x-24,47,49,62))
        height = max(4,round(55*(1-blink)))
        top = 79-height/2
        story_ellipse(head,(248,247,221),(x-21,top,43,height))
        if blink < .7:
            px = x+look*6
            story_ellipse(head,(60,78,51),(px-14,top+6,29,height-8))
            story_ellipse(head,(26,49,40),(px-10,top+10,21,height-13))
            story_ellipse(head,(255,255,244),(px-7,top+12,10,13))
            story_ellipse(head,(221,239,211),(px+4,top+32,4,5))
        else:
            pygame.draw.arc(head,(43,94,68),(x-20,73,40,12),math.pi,math.tau,2)
    # Raised inner brows and a tiny uncertain mouth — concerned, not terrified.
    if happy:
        pygame.draw.arc(head,(44,106,76),(43,32,31,16),.2,math.pi-.2,2)
        pygame.draw.arc(head,(44,106,76),(116,32,31,16),.2,math.pi-.2,2)
    else:
        pygame.draw.lines(head,(44,106,76),False,[(40,44),(53,39),(73,35)],3)
        pygame.draw.lines(head,(44,106,76),False,[(115,35),(136,39),(149,44)],3)
    story_ellipse(head,(80,142,96),(89,107,5,3));story_ellipse(head,(80,142,96),(103,107,5,3))
    if happy:
        story_shape(head,(35,84,66),[(77,117),(88,123),(99,125),(111,122),(121,116),(115,131),(103,137),(91,135),(82,128)])
        story_ellipse(head,(221,160,133),(91,130,20,5))
    else:
        pygame.draw.arc(head,(62,116,77),(84,119,28,12),.12,math.pi-.12,2)
    head = pygame.transform.rotozoom(head,-look*5,1)
    surface.blit(head,head.get_rect(center=(520+look*8,355+breath)))


class Game:
    def __init__(self):
        self.line_input = InputBox(PANEL_LEFT, 165, 345, 43)
        self.next_button = Button(PANEL_LEFT, 770, 160, 46, "Next Level")
        self.retry_button = Button(PANEL_LEFT, 770, 140, 46, "Try Again")
        self.restart_button = Button(PANEL_LEFT, 770, 170, 46, "Restart Game")

        self.show_grid = False
        self.immersive = False
        self.menu_visible = True
        self.manual_pause = False
        self.new_journey()
        self.crab_seed = random.randrange(100000000)
        self.level = 0
        self.state = "playing"
        self.level_scores = []
        self.last_level_score = None
        self.celebration_time = 0.0
        self.start_level()
        self.state="intro";self.intro_time=0.0

    def new_journey(self):
        self.wallet=0;self.turbo_charges=1;self.shell_charges=1;self.circle_charges=0
        self.circle_unlocked=False;self.shell_held=False;self.circle_price=8
        self.super_charges=0;self.trap_kind="circle";self.turbo_available=True;self.purchased_total={}
        self.turbo_remaining=0.0;self.shell_remaining=0.0
        self.shell_fold=0.0;self.shell_grace=0.0
        self.shop_visited=False;self.shop_stops=set();self.shell_contacts=set()
        self.inventory_level=None
        self.obstacle_schedule=self.make_obstacle_schedule()
        for level in random.sample(range(2,9),3):self.obstacle_schedule[level].append("towel")
        self.seen_props=set()
        directions=["left","right","bottom","top"]
        random.shuffle(directions)
        second=directions[:];random.shuffle(second)
        lateral=["left","right"];random.shuffle(lateral)
        self.direction_schedule=directions+second+lateral
        index=self.direction_schedule.index("left");self.direction_schedule[0],self.direction_schedule[index]=self.direction_schedule[index],self.direction_schedule[0]
        self.hawk_schedule=self.make_hawk_schedule()
        # Crabs arrive alone in round 2; pairs first appear in round 6.
        # Keep later appearances varied, with no more than two at a time.
        self.crab_schedule=[0,1,1]+[random.choices((0,1),(.30,.70))[0] for _ in range(2)]+[2]
        self.crab_schedule += [random.choices((0,1,2),(.20,.30,.50))[0] for _ in range(4)]

    # -------------------- ROUND-FIVE SHOP / POWER-UPS --------------------
    def enter_shop(self,next_level=4):
        if next_level in self.shop_stops:return
        self.shop_stops.add(next_level);self.shop_next_level=next_level
        self.shop_visited=True;self.shop_purchased={}
        stop={4:0,6:1,8:2}[next_level]
        first=stop==0
        if first:
            self.shop_average=sum(self.level_scores[:4])/4
            self.shop_earnings=math.ceil(max(0.0,min(100.0,self.shop_average))/5)
            self.wallet+=self.shop_earnings
            self.shop_items=[("shell",6),("turbo",4)]
            problem=dict(title="Problem to Solve for an Extra $6",lines=[
                "A shell protection costs $2 more than a turbo boost.",
                "Two shell protections and three turbo boosts cost $24. Find each price."],
                labels=("Shell price ($)","Turbo price ($)"),answers=(6,4),
                hint="Find two equations and use substitution. The first equation can be: shell_price = turbo_price + 2 and the second can be: 2 × shell_price + ... = 24.")
            self.shop_story="Good job! Spend your earnings on more supplies, or save your money for later."
        elif stop==1:
            self.circle_unlocked=True;self.turbo_available=True
            self.shop_items=[("shell",7),("circle",8)]
            problem=dict(title="Solve this Problem to Help a Tired Hatchling",lines=[
                "An ordinary circle trap costs $1 more than a shell protection.",
                "Three shell protections and two ordinary traps cost $37. Find each price."],
                labels=("Shell price ($)","Ordinary trap price ($)"),answers=(7,8),
                hint="Let trap_price = shell_price + 1. Substitute into 3 × shell_price + 2 × trap_price = 37.")
            self.shop_story="Turbo is not sold here, but you can still use your saved boosts in every round."
        else:
            self.circle_unlocked=True;self.turbo_available=True;self.trap_kind="super"
            self.shop_items=[("turbo",5),("super",14)]
            problem=dict(title="Last Problem to Solve to Help the Hatchling Reach the Ocean",lines=[
                "Three turbo boosts and two super circle traps cost $43.",
                "Two turbo boosts and three super circle traps cost $52. Find each price."],
                labels=("Turbo price ($)","Super trap price ($)"),answers=(5,14),
                hint="Find the two equations, multiply the first equation by 2 and the second by 3, then subtract to eliminate a variable.")
            self.shop_story="The ocean is close! Buy turbo boosts or super traps; no shell protections for sale."
        if not first:
            recent=self.level_scores[next_level-2:next_level]
            self.shop_earnings=math.ceil((sum(recent)/max(1,len(recent)))/5)
            self.wallet+=self.shop_earnings
        self.shop_problems=[problem];self.shop_problem_index=0
        self.shop_shell_input=InputBox(0,0,160,40);self.shop_turbo_input=InputBox(0,0,160,40)
        self.shop_shell_quantity=InputBox(0,0,52,34);self.shop_turbo_quantity=InputBox(0,0,52,34)
        self.shop_shell_quantity.text=self.shop_turbo_quantity.text="1"
        self.load_shop_problem()
        self.state="shop";self.menu_visible=False;self.line_input.active=False
        self.manual_pause=False;self.layout_shop()

    def layout_shop(self):
        self.shop_rect=pygame.Rect(WIDTH//2-470,HEIGHT//2-425,940,850)
        x,y=self.shop_rect.topleft
        self.shop_shell_input.rect.update(x+28,y+336,174,38)
        self.shop_turbo_input.rect.update(x+254,y+336,174,38)
        self.shop_check=pygame.Rect(x+640,y+336,272,38)
        self.shop_reveal=pygame.Rect(x+28,y+385,260,34)
        self.shop_hint=pygame.Rect(x+302,y+385,130,34)
        self.shop_quantity_buttons={}
        for i,(kind,_) in enumerate(self.shop_items):
            dx=28+i*456
            box=(self.shop_shell_quantity,self.shop_turbo_quantity)[i]
            box.rect.update(x+dx+56,y+690,52,34)
            self.shop_quantity_buttons[kind]={-1:pygame.Rect(x+dx+119,y+690,30,34),1:pygame.Rect(x+dx+157,y+690,30,34)}
        self.shop_buy_shell=pygame.Rect(x+228,y+690,224,34)
        self.shop_buy_turbo=pygame.Rect(x+684,y+690,224,34)
        self.shop_continue=pygame.Rect(x+612,y+786,300,42)

    def check_shop_answer(self):
        if self.shop_solved or self.shop_revealed:
            if self.shop_problem_index+1<len(self.shop_problems):
                self.shop_problem_index+=1;self.load_shop_problem()
            return
        def number(text):
            try:
                value=float(text.strip().replace("$","").replace(",","."))
                return value if math.isfinite(value) else None
            except ValueError:return None
        values=(number(self.shop_shell_input.text),number(self.shop_turbo_input.text))
        answers=self.shop_problems[self.shop_problem_index]['answers']
        if any(value is None for value in values):
            self.shop_feedback="Enter a number in both answer boxes.";self.shop_feedback_colour=RED;return
        if all(abs(v-a)<.005 for v,a in zip(values,answers)):
            self.shop_solved=True;self.shop_shell_input.active=self.shop_turbo_input.active=False
            if not self.shop_bonus_paid:self.wallet+=6;self.shop_bonus_paid=True
            self.shop_feedback="Correct! An extra $6 bonus is in your wallet. You can buy supplies below."
            self.shop_feedback_colour=DARK_GREEN
        else:
            self.shop_feedback="Not quite. Use both pieces of information and try again, or ask for a hint."
            self.shop_feedback_colour=RED

    @staticmethod
    def supply_info(kind):
        return {
            "shell":("Shell protection [S]",(30,123,105),"Hold S to hide; release to move. Each hit uses one.","shell_charges"),
            "turbo":("Turbo boost [T]",(179,91,25),"2.9× speed for 3 seconds, with a countdown.","turbo_charges"),
            "circle":("Ordinary circle [C]",(32,111,175),"Radius ≤ 5. Captures once; its edge is a barrier.","circle_charges"),
            "super":("Super circle [C]",(112,70,165),"Radius 4–10. Also captures new arrivals.","super_charges")}[kind]

    @staticmethod
    def supply_name(kind,quantity):
        name={"shell":"shell protection","turbo":"turbo boost","circle":"ordinary trap","super":"super trap"}[kind]
        return name+("s" if quantity!=1 else "")

    def buy_powerup(self,kind,quantity=None):
        offered=dict(self.shop_items)
        if kind not in offered:
            self.shop_feedback="That item is not sold at this supply stop.";self.shop_feedback_colour=RED;return
        if not (self.shop_solved or self.shop_revealed):
            self.shop_feedback="Solve the prices for a bonus, or skip to reveal prices and buy.";self.shop_feedback_colour=BLUE;return
        index=[k for k,_ in self.shop_items].index(kind)
        box=(self.shop_shell_quantity,self.shop_turbo_quantity)[index]
        quantity=self.shop_quantity(box) if quantity is None else quantity
        if not isinstance(quantity,int) or isinstance(quantity,bool) or not 1<=quantity<=99:
            self.shop_feedback="Enter a whole-number quantity from 1 to 99.";self.shop_feedback_colour=RED;return
        cost=offered[kind]*quantity
        if self.wallet<cost:
            self.shop_feedback=f"That costs ${cost}; you have ${self.wallet}. Choose a smaller quantity.";self.shop_feedback_colour=RED;return
        self.wallet-=cost
        title,colour,description,attribute=self.supply_info(kind)
        setattr(self,attribute,getattr(self,attribute)+quantity)
        self.shop_purchased[kind]=self.shop_purchased.get(kind,0)+quantity
        self.purchased_total[kind]=self.purchased_total.get(kind,0)+quantity
        self.shop_feedback=f"Purchase confirmed: +{quantity} {self.supply_name(kind,quantity)}. You currently have {getattr(self,attribute)}."
        self.shop_feedback_colour=DARK_GREEN;self.inventory_level=None

    def handle_shop_event(self,event):
        self.layout_shop()
        key=event.key if event.type==pygame.KEYDOWN else None
        click=event.type==pygame.MOUSEBUTTONDOWN and event.button==1
        boxes=(self.shop_shell_input,self.shop_turbo_input,self.shop_shell_quantity,self.shop_turbo_quantity)
        if click:
            for box in boxes:box.active=False
            if self.shop_continue.collidepoint(event.pos):
                self.level=self.shop_next_level;self.inventory_level=None;self.start_level()
                return
            if self.shop_check.collidepoint(event.pos):self.check_shop_answer();return
            if self.shop_buy_shell.collidepoint(event.pos):self.buy_powerup(self.shop_items[0][0]);return
            if self.shop_buy_turbo.collidepoint(event.pos):self.buy_powerup(self.shop_items[1][0]);return
            for kind,box in zip((item[0] for item in self.shop_items),(self.shop_shell_quantity,self.shop_turbo_quantity)):
                for step,rect in self.shop_quantity_buttons[kind].items():
                    if rect.collidepoint(event.pos):
                        box.text=str(max(1,min(99,(self.shop_quantity(box) or 1)+step)));return
            if self.shop_reveal.collidepoint(event.pos) and not self.shop_solved:
                self.shop_revealed=True
                for box in boxes:box.active=False
                self.shop_feedback="Question skipped. You can still buy supplies below."
                self.shop_feedback_colour=BLUE;return
            if self.shop_hint.collidepoint(event.pos):
                self.shop_feedback=self.shop_problems[self.shop_problem_index]['hint']
                self.shop_feedback_colour=BLUE;return
            for box in boxes:
                enabled=box in (self.shop_shell_quantity,self.shop_turbo_quantity) or not (self.shop_solved or self.shop_revealed)
                box.active=enabled and box.rect.collidepoint(event.pos)
            return
        if key==pygame.K_ESCAPE:
            for box in boxes:box.active=False
            return
        if key==pygame.K_TAB:
            enabled=list(boxes[2:] if self.shop_solved or self.shop_revealed else boxes)
            active=next((i for i,box in enumerate(enabled) if box.active),-1)
            for box in boxes:box.active=False
            enabled[(active+1)%len(enabled)].active=True;return
        if key==pygame.K_RETURN:
            if self.shop_shell_quantity.active:self.buy_powerup(self.shop_items[0][0])
            elif self.shop_turbo_quantity.active:self.buy_powerup(self.shop_items[1][0])
            else:self.check_shop_answer()
            return
        for box in boxes:
            if box.active:box.handle_event(event)

    def activate_powerup(self,kind):
        if kind=="turbo":
            if not self.turbo_available:self.message="The turtle is resting: turbo returns after round 8."
            elif self.turbo_remaining>0:self.message="Turbo is already running; watch its countdown."
            elif self.shell_remaining>0 or self.shell_fold>.01:self.message="Wait for the turtle to unfold before boosting."
            elif self.turbo_charges>0:
                self.turbo_charges-=1;self.turbo_remaining=TURBO_DURATION
                self.message="Turbo started: 2.9 times normal speed for three seconds."
            else:self.message="No turbo boosts left."
        else:
            self.shell_held=self.shell_charges>0
            self.shell_remaining=1.0 if self.shell_held else 0.0
            self.shell_fold=1.0 if self.shell_held else 0.0
            self.message="Hold S to stay in your shell. Release S to move." if self.shell_held else "No shell protections left."
        self.message_colour=BLUE

    def update_shell(self,dt):
        active=self.shell_held and self.shell_charges>0
        self.shell_remaining=1.0 if active else 0.0
        self.shell_fold=1.0 if active else 0.0
        self.shell_grace=0.0


    # -------------------- CIRCLE TRAPS (ROUNDS 9–10) --------------------
    def circle_layout(self):
        # Share the controls' side; leave the central beach visible while typing.
        left=8 if self.corner_x<WIDTH/2 else WIDTH-328
        self.circle_rect=pygame.Rect(left,338,320,506)
        x,y=self.circle_rect.topleft
        self.circle_inputs[0].rect.update(x+30,y+180,76,36)
        self.circle_inputs[1].rect.update(x+132,y+180,76,36)
        self.circle_inputs[2].rect.update(x+114,y+234,76,36)
        self.circle_place=pygame.Rect(x+16,y+410,288,40)
        self.circle_cancel=pygame.Rect(x+16,y+460,288,36)
        self.trap_select={"circle":pygame.Rect(x+16,y+118,140,30),"super":pygame.Rect(x+164,y+118,140,30)}

    def circle_values(self):
        values=[]
        for box in self.circle_inputs:
            try:value=float(box.text.strip())
            except ValueError:return None
            if not math.isfinite(value):return None
            values.append(value)
        return values

    def handle_circle_event(self,event):
        self.circle_layout()
        key=event.key if event.type==pygame.KEYDOWN else None
        click=event.type==pygame.MOUSEBUTTONDOWN and event.button==1
        if not self.circle_entry:
            self.circle_entry=True;self.line_input.active=False;self.menu_visible=False
            self.circle_confirm=None
            if getattr(self,self.trap_kind+"_charges")==0:
                self.trap_kind="circle" if self.circle_charges else "super" if self.super_charges else "circle"
            self.circle_feedback="Choose a trap, centre and radius. Entry pauses the beach."
            self.circle_inputs[0].active=True
            return
        if key==pygame.K_ESCAPE or (click and self.circle_cancel.collidepoint(event.pos)):
            self.circle_entry=False;return
        if key==pygame.K_TAB:
            active=next((i for i,b in enumerate(self.circle_inputs) if b.active),-1)
            for b in self.circle_inputs:b.active=False
            self.circle_inputs[(active+1)%3].active=True;return
        if click:
            for kind,rect in self.trap_select.items():
                if rect.collidepoint(event.pos):
                    self.trap_kind=kind;self.circle_confirm=None;return
        if key==pygame.K_RETURN or (click and self.circle_place.collidepoint(event.pos)):
            values=self.circle_values()
            if not values:self.circle_feedback="Enter finite numbers for the centre and radius.";return
            h,k,r=values
            if not (X_MIN<=h<=X_MAX and Y_MIN<=k<=Y_MAX and (4<=r<=10 if self.trap_kind=="super" else 2<=r<=5)):
                self.circle_feedback="Choose a centre on the beach and a radius from "+("4 to 10." if self.trap_kind=="super" else "2 to 5.");return
            attribute=self.trap_kind+"_charges"
            if getattr(self,attribute)<=0:self.circle_feedback="None of this trap type left. Select another type or cancel.";return
            effective=r
            if any(math.dist((h,k),barrier['circle'][:2])<effective+barrier['circle'][2]+.5 for barrier in self.traps):
                self.circle_feedback="Keep circles separate so their barriers do not overlap.";return
            signature=(self.trap_kind,h,k,r)
            if self.level==8 and self.circle_charges+self.super_charges==1 and self.circle_confirm!=signature:
                self.circle_confirm=signature
                self.circle_feedback="Round 10 is much harder. Last trap! Enter again to use it, or Cancel."
                return
            setattr(self,attribute,getattr(self,attribute)-1)
            radius=r
            trap={"circle":(h,k,radius),"super":self.trap_kind=="super","members":set()}
            self.traps.append(trap);self.circle_entry=False;self.capture_hawks(placed=trap)
            self.message="Super trap placed: it captures hawks entering later." if trap['super'] else "Barrier placed: only the hawks captured now stay inside."
            return
        if click:
            for box in self.circle_inputs:box.active=box.rect.collidepoint(event.pos)
        else:
            for box in self.circle_inputs:
                if box.active:box.handle_event(event)

    def draw_circle_entry(self):
        self.circle_layout();card=self.circle_rect;x,y=card.topleft
        pygame.draw.rect(SCREEN,(250,246,239),card,border_radius=10)
        colour=PURPLE if self.trap_kind=="super" else BLUE
        pygame.draw.rect(SCREEN,colour,card,2,border_radius=10)
        def text(value,dx,dy,font=SMALL_FONT):SCREEN.blit(font.render(value,True,colour),(x+dx,y+dy))
        text("Place a circle trap",16,16,FONT)
        text("(x − h)² + (y − k)² = r²",16,49)
        for kind,rect in self.trap_select.items():
            pygame.draw.rect(SCREEN,(225,214,240) if kind==self.trap_kind else (228,234,236),rect,border_radius=5)
            caption=("Ordinary" if kind=="circle" else "Super")+f": {getattr(self,kind+'_charges')}"
            label=TINY_FONT.render(caption,True,colour);SCREEN.blit(label,label.get_rect(center=rect.center))
        text("Centre = (h, k)",16,154)
        text("(",16,188);text(",",114,188);text(")",216,188)
        text("Radius =",16,243)
        for box in self.circle_inputs:box.draw()
        text("Radius: 4–10. Tab: next box." if self.trap_kind=="super" else "Radius: 2–5. Tab: next box.",16,280,TINY_FONT)
        text("Super: catches new arrivals too." if self.trap_kind=="super" else "Ordinary: captures at placement.",16,305,TINY_FONT)
        text("Most of the hawk must fit inside.",16,325,TINY_FONT)
        feedback_colour=(166,62,35) if self.circle_confirm else colour
        for i,line in enumerate(wrap_text(self.circle_feedback,TINY_FONT,288)[:3]):
            SCREEN.blit(TINY_FONT.render(line,True,feedback_colour),(x+16,y+350+i*18))
        for rect,caption in ((self.circle_place,"Use last trap [Enter]" if self.circle_confirm else "Place circle [Enter]"),(self.circle_cancel,"Cancel [Esc]")):
            pygame.draw.rect(SCREEN,(225,215,240) if self.trap_kind=="super" else (213,232,241),rect,border_radius=6)
            label=SMALL_FONT.render(caption,True,colour);SCREEN.blit(label,label.get_rect(center=rect.center))

    @staticmethod
    def hawk_trap_geometry(hawk):
        """Cache the original opaque samples and shape bounds for each pose."""
        sprite = hawk.sprite
        key = (hawk.kind, id(sprite))
        if not hasattr(Hawk, '_trap_geometry'):
            Hawk._trap_geometry = {}
        if key not in Hawk._trap_geometry:
            w, h = sprite.get_size()
            step = max(2, round(min(w, h)/24))
            samples = [((x-w/2)/(850/40), -(y-h/2)/(850/40))
                       for y in range(step//2, h, step)
                       for x in range(step//2, w, step) if sprite.get_at((x, y)).a > 170]
            radii = sorted(math.hypot(u, v) for u, v in samples)
            maximum = radii[-1] if radii else 0.0
            envelope65 = radii[min(len(radii)-1, math.ceil(len(radii)*.65))] if radii else 0.0
            cross_extent = max((abs(v) for u, v in samples), default=0.0)
            Hawk._trap_geometry[key] = (samples, maximum, envelope65, cross_extent)
        return Hawk._trap_geometry[key]

    @staticmethod
    def hawk_fraction_in_circle(hawk, trap, position=None, direction=None):
        samples, maximum, _, _ = Game.hawk_trap_geometry(hawk)
        if not samples:
            return 0.0
        px, py = position if position is not None else hawk.position()
        vx, vy = direction if direction is not None else (hawk.line.dx*hawk.direction, hawk.line.dy*hawk.direction)
        h, k, r = trap
        # Conservative bounds: only skip when every sample is certainly outside
        # or inside. Borderline cases still use the original majority test.
        extent = maximum*math.hypot(vx, vy)
        distance2 = (px-h)**2+(py-k)**2
        if distance2 > (r+extent+1e-9)**2:
            return 0.0
        if r > extent and distance2 < (r-extent-1e-9)**2:
            return 1.0
        return sum((px+u*vx-v*vy-h)**2+(py+u*vy+v*vx-k)**2 <= r*r
                   for u, v in samples)/len(samples)

    def capture_hawks(self,placed=None):
        # Ordinary circles get exactly one capture pass, at placement.
        for hawk in self.hawks:
            if getattr(hawk,'trap',None) is not None:continue
            for barrier in self.traps:
                if not barrier['super'] and barrier is not placed:continue
                trap=barrier['circle']
                if self.hawk_fraction_in_circle(hawk,trap)>.5:
                    hawk.trap=trap;hawk.trap_position=hawk.position()
                    hawk.trap_heading=math.atan2(hawk.line.dy*hawk.direction,hawk.line.dx*hawk.direction)
                    barrier['members'].add(hawk);break

        if placed is not None and not placed['super']:
            self.release_uncaptured_hawks(placed)

    def release_uncaptured_hawks(self,barrier):
        """Classify each nonmember once, and let overlapping birds fly out."""
        for bird in self.hawks:
            if getattr(bird,'trap',None) is not None:continue
            interval=self.hawk_barrier_interval(bird,barrier['circle'])
            if interval is None:continue
            low,high=interval
            side=-1 if bird.t<(low+high)/2 else 1
            # Prefer an exit that fits inside the bird's original screen path.
            endpoints=bird.line.visible_endpoints()
            if len(endpoints)==2:
                left,right=sorted(x*bird.line.dx+y*bird.line.dy for x,y in endpoints)
                if side<0 and low<left+bird.beak_reach:side=1
                elif side>0 and high>right-bird.beak_reach:side=-1
            if not hasattr(bird,'ordinary_sides'):bird.ordinary_sides={}
            bird.ordinary_sides[id(barrier)]=side
            if low<=bird.t<=high:
                # Do not teleport the bird or run another capture pass. It keeps
                # flying along this outward heading until it is fully clear.
                bird.direction=side;bird.previous_direction=side

    def hawk_barrier_interval(self,hawk,trap,direction=None):
        samples, _, _, cross_extent = self.hawk_trap_geometry(hawk)
        h,k,r=trap;dx,dy=hawk.line.dx,hawk.line.dy
        px,py=hawk.position();base=(px-dx*hawk.t,py-dy*hawk.t)
        centre_t=(h-base[0])*dx+(k-base[1])*dy
        offset=(base[0]-h)*(-dy)+(base[1]-k)*dx
        heading=hawk.direction if direction is None else direction
        if abs(offset) > r+cross_extent+1e-9:
            return None
        key = (id(hawk.sprite), tuple(trap), heading, hawk.line.A, hawk.line.B, hawk.line.C)
        cache = getattr(hawk, '_barrier_intervals', None)
        if cache is None:
            cache = hawk._barrier_intervals = {}
        if key in cache:
            return cache[key]
        low=math.inf;high=-math.inf
        for u,v in samples:
            cross=offset+heading*v
            if abs(cross)>r:continue
            reach=math.sqrt(max(0,r*r-cross*cross))
            centre=centre_t-heading*u
            low=min(low,centre-reach);high=max(high,centre+reach)
        result = None if low == math.inf else (low, high)
        if len(cache) >= 384:
            cache.clear()
        cache[key] = result
        return result

    def update_free_hawk(self,hawk,dt):
        old_t=hawk.t;old_direction=hawk.direction
        hawk.update(dt)
        for barrier in self.traps:
            if barrier['super']:continue
            interval=self.hawk_barrier_interval(hawk,barrier['circle'],old_direction)
            if interval is None:continue
            low,high=interval
            if not hasattr(hawk,'ordinary_sides'):hawk.ordinary_sides={}
            key=id(barrier)
            side=hawk.ordinary_sides.setdefault(key,-1 if old_t<(low+high)/2 else 1)
            # A grazing bird can pass a circle with its wings folded and later
            # open them on the other side. Do not pull it backwards across it.
            if side<0 and old_t>high and old_direction>0:side=1
            elif side>0 and old_t<low and old_direction<0:side=-1
            hawk.ordinary_sides[key]=side
            # Only an APPROACH can trigger a circle bounce. Once turned away,
            # opening wings or the changed silhouette after a 180-degree turn
            # must never turn the bird back into the barrier on the next frame.
            if side<0 and old_direction>0 and hawk.t>=low:
                hawk.t=min(old_t,low-.002);hawk.direction=-1;break
            if side>0 and old_direction<0 and hawk.t<=high:
                hawk.t=max(old_t,high+.002);hawk.direction=1;break

    def update_trapped_hawk(self,hawk,dt):
        if getattr(hawk,'trap',None) is None:self.update_free_hawk(hawk,dt);return
        hawk.update_wings(dt)
        old=hawk.position();hawk.previous_position=old;hawk.previous_direction=hawk.direction
        h,k,r=hawk.trap
        samples, maximum, envelope65, _ = self.hawk_trap_geometry(hawk)
        # Keep at least 65% of the current silhouette inside for every heading,
        # including when the wings open wider after capture.
        envelope = maximum
        if envelope >= r and samples:
            envelope = envelope65
        safe=max(0.0,r-envelope-.02)
        offset=pygame.Vector2(hawk.trap_position)-pygame.Vector2(h,k)
        if offset.length()>safe:
            offset.scale_to_length(safe)
            hawk.trap_position=(h+offset.x,k+offset.y)
        remaining=dt
        while remaining>1e-9:
            step=min(remaining,.025);remaining-=step
            velocity=pygame.Vector2(math.cos(hawk.trap_heading),math.sin(hawk.trap_heading))
            offset=pygame.Vector2(hawk.trap_position)-pygame.Vector2(h,k)
            target=offset+velocity*hawk.speed*step
            if target.length()>safe:
                if target.length()>1e-9:
                    normal=target.normalize();velocity=velocity.reflect(normal)
                target=offset+velocity*hawk.speed*step
                if target.length()>safe:target.scale_to_length(safe)
            hawk.trap_position=(h+target.x,k+target.y)
            hawk.trap_heading=math.atan2(velocity.y,velocity.x)
            hawk.line=Line(-velocity.y,velocity.x,0);hawk.direction=1

    def draw_traps(self, preview_only=False, include_preview=True):
        if (preview_only or not self.traps) and not (include_preview and self.circle_entry):
            return
        if getattr(self, "_trap_layer", None) is None or self._trap_layer.get_size() != (WIDTH, HEIGHT):
            self._trap_layer = pygame.Surface((WIDTH, HEIGHT), pygame.SRCALPHA)
        layer = self._trap_layer
        layer.fill((0, 0, 0, 0))
        for barrier in (() if preview_only else self.traps):
            h,k,r=barrier['circle']
            centre=graph_to_screen(h,k);radius=round(r*SCALE)
            pygame.draw.circle(layer,(58,167,207,25),centre,radius)
            pygame.draw.circle(layer,(119,64,180,220) if barrier["super"] else (24,126,184,210),centre,radius,3)
            pygame.draw.circle(layer,(24,126,184,210),centre,3)
        # Live preview helps place a circle while the hawks remain visible.
        if include_preview and self.circle_entry:
            values=self.circle_values()
            if values:
                h,k,r=values
                if X_MIN<=h<=X_MAX and Y_MIN<=k<=Y_MAX and (4<=r<=10 if self.trap_kind=="super" else 2<=r<=5):
                    centre=graph_to_screen(h,k)
                    pygame.draw.circle(layer,(112,70,165,190) if self.trap_kind=="super" else (35,139,193,190),centre,round(r*SCALE),2)
                    pygame.draw.circle(layer,(35,139,193,220),centre,4,1)
        SCREEN.blit(layer,(0,0))

    def draw_power_hud(self):
        box=pygame.Rect(self.corner_x+8,164,202,122)
        pygame.draw.rect(SCREEN,(237,246,239),box,border_radius=7)
        lines=[f"T: Turbo | {self.turbo_charges} left",
               f"2.9×: {self.turbo_remaining:.1f}s left" if self.turbo_remaining>0 else "3 seconds per boost",
               f"S: Shell | {self.shell_charges} left",f"Wallet: ${self.wallet}"]
        if not self.turbo_available:lines[0]="Turbo resting (saved)"
        if self.circle_unlocked:lines[1]=f"C: {self.circle_charges} ordinary | {self.super_charges} super"
        if self.turbo_remaining>0:lines[0]=f"TURBO: {self.turbo_remaining:.1f}s left"
        if self.shell_held:lines[2]=f"Shelled up | {self.shell_charges} left"
        for i,line in enumerate(lines):SCREEN.blit(TINY_FONT.render(line,True,DARK_GREEN),(box.x+8,box.y+8+i*24))
        track=pygame.Rect(box.x+8,box.bottom-12,186,5)
        pygame.draw.rect(SCREEN,(207,224,213),track,border_radius=2)
        if self.turbo_remaining>0:pygame.draw.rect(SCREEN,(231,146,43),(track.x,track.y,round(track.width*self.turbo_remaining/TURBO_DURATION),5),border_radius=2)

    def draw_shop(self):
        self.layout_shop();card=self.shop_rect;x,y=card.topleft
        veil=pygame.Surface((WIDTH,HEIGHT),pygame.SRCALPHA);veil.fill((22,44,53,145));SCREEN.blit(veil,(0,0))
        pygame.draw.rect(SCREEN,(246,249,244),card,border_radius=16)
        def text(value,dx,dy,font=SMALL_FONT,colour=BLACK):SCREEN.blit(font.render(value,True,colour),(x+dx,y+dy))
        def button(rect,caption,enabled=True,colour=(34,112,159)):
            pygame.draw.rect(SCREEN,colour if enabled else (216,223,223),rect,border_radius=6)
            label=SMALL_FONT.render(caption,True,WHITE if enabled else GREY)
            SCREEN.blit(label,label.get_rect(center=rect.center))
        head=pygame.Rect(x,y,940,88);pygame.draw.rect(SCREEN,(27,75,92),head,border_radius=16)
        text(f"Supply Stop",28,17,TITLE_FONT,WHITE)
        text("Solve for the prices, earn an extra $6, then choose what to buy.",28,54,SMALL_FONT,(209,232,232))
        wallet=pygame.Rect(x+708,y+16,204,56);pygame.draw.rect(SCREEN,(218,240,226),wallet,border_radius=8)
        text(f"Wallet: ${self.wallet}",724,29,FONT,DARK_GREEN)
        for i,line in enumerate(wrap_text(self.shop_story,SMALL_FONT,884)[:2]):text(line,28,105+22*i,SMALL_FONT,DARK_GREEN)
        if self.shop_next_level==4:
            text(f"First-four average: {self.shop_average:.1f}/100 → ${self.shop_earnings} ($2 per 10 points, rounded up).",28,155,TINY_FONT,GREY)
        elif self.shop_next_level==6:
            text(f"Earned ${self.shop_earnings} from rounds 5–6. Ordinary traps capture once, then act as barriers.",28,155,TINY_FONT,BLUE)
        else:
            text(f"Earned ${self.shop_earnings} from rounds 7–8. Super circle traps: radius 4–10; capture new arrivals too.",28,155,TINY_FONT,PURPLE)
        problem=self.shop_problems[0];answered=self.shop_solved or self.shop_revealed
        panel=pygame.Rect(x+16,y+190,908,238);pygame.draw.rect(SCREEN,WHITE,panel,border_radius=10)
        text(problem['title'],28,203,FONT)
        for i,line in enumerate(problem['lines']):text(line,28,242+26*i)
        for i,(box,label,answer) in enumerate(zip((self.shop_shell_input,self.shop_turbo_input),problem['labels'],problem['answers'])):
            dx=28+226*i;text(label,dx,312,TINY_FONT)
            if answered:
                pygame.draw.rect(SCREEN,(224,241,229),box.rect,border_radius=5);text(f"${answer}",dx+12,342,FONT,DARK_GREEN)
            else:box.draw()
        button(self.shop_check,"Bonus earned!" if self.shop_solved else "Prices revealed" if self.shop_revealed else "Check prices",not answered)
        button(self.shop_reveal,"Skip / reveal prices",not answered,(91,113,121));button(self.shop_hint,"Hint",True,(91,113,121))
        feedback=pygame.Rect(x+28,y+442,884,58);pygame.draw.rect(SCREEN,(226,241,231) if self.shop_feedback_colour==DARK_GREEN else (231,240,248),feedback,border_radius=7)
        for i,line in enumerate(wrap_text(self.shop_feedback,SMALL_FONT,856)[:2]):text(line,42,450+i*22,SMALL_FONT,self.shop_feedback_colour)
        boxes=(self.shop_shell_quantity,self.shop_turbo_quantity);buy_buttons=(self.shop_buy_shell,self.shop_buy_turbo)
        for i,((kind,price),box,buy) in enumerate(zip(self.shop_items,boxes,buy_buttons)):
            dx=28+i*456;title,colour,description,attribute=self.supply_info(kind)
            tile=pygame.Rect(x+dx,y+518,428,218);pygame.draw.rect(SCREEN,WHITE,tile,border_radius=9)
            pygame.draw.rect(SCREEN,colour,(x+dx,y+518,428,6),border_radius=3)
            text(title,dx+14,534,FONT,colour)
            badge=pygame.Rect(x+dx+14,y+570,400,50);pygame.draw.rect(SCREEN,colour,badge,border_radius=7)
            text(f"Currently have: {getattr(self,attribute)}",dx+26,579,TITLE_FONT,WHITE)
            text(f"Bought here: {self.shop_purchased.get(kind,0)}  |  Total purchased: {self.purchased_total.get(kind,0)}",dx+14,628,SMALL_FONT,colour)
            for line_index,line in enumerate(wrap_text(description,TINY_FONT,400)[:2]):
                text(line,dx+14,653+line_index*18,TINY_FONT,GREY)
            text("Qty",dx+14,699,TINY_FONT)
            box.draw()
            for step,rect in self.shop_quantity_buttons[kind].items():button(rect,"+" if step==1 else "−",True,colour)
            qty=self.shop_quantity(box)
            caption="Solve / skip first" if not answered else f"Buy {qty} for ${price*qty}" if qty else "Enter quantity"
            button(buy,caption,bool(answered and qty and self.wallet>=qty*price),colour)
            if answered:text(f"${price} each",dx+315,541,TINY_FONT,colour)
        if not answered:reminder="Solve or skip to unlock buying. You can also continue without buying."
        else:
            options=[f"{self.wallet//price} {self.supply_name(kind,self.wallet//price)}" for kind,price in self.shop_items if self.wallet>=price]
            reminder=f"${self.wallet} left — enough for "+" or ".join(options)+"." if options else f"${self.wallet} left. No more supplies are affordable; continue when ready."
        for i,line in enumerate(wrap_text(reminder,TINY_FONT,884)[:2]):text(line,28,748+i*17,TINY_FONT,DARK_GREEN)
        text("Save unspent money for a later supply stop." if self.shop_next_level<8 else "Last supply stop: only 2 more rounds to use your supplies",28,802,TINY_FONT,DARK_GREEN)
        button(self.shop_continue,f"Start round {self.shop_next_level+1}",True,(28,128,95))

    def load_shop_problem(self):
        self.shop_solved=False;self.shop_revealed=False;self.shop_bonus_paid=False
        self.shop_shell_input.text=self.shop_turbo_input.text=""
        self.shop_shell_input.active=self.shop_turbo_input.active=False
        self.shop_feedback="A correct answer earns an extra $6 bonus to spend on supplies."
        self.shop_feedback_colour=DARK_GREEN

    @staticmethod
    def shop_quantity(box):
        value=box.text.strip()
        return int(value) if re.fullmatch(r"[1-9][0-9]?",value) else None

    @staticmethod
    def story_sprite(time,happy=False):
        source=pygame.Surface((760,580),pygame.SRCALPHA)
        story_draw_hatchling(source,time,happy=happy,swimming=happy)
        return source.subsurface((415,270,205,260)).copy()

    def intro_layout(self):
        key = (WIDTH, HEIGHT, id(INTRO_FONT), id(SMALL_FONT))
        if getattr(self, "_intro_key", None) != key:
            paragraphs = [
                ("A little late, and all alone…", DARK_GREEN),
                ("This tiny turtle has only just hatched. Its brothers and sisters left long ago, so there is no one to follow towards the ocean.", BLACK),
                ("Be its guide! Lead it to safe sand hollows, then finally to the ocean. Dangerous hawks fly over the beach, so choose your paths carefully.", BLACK),
                ("Draw paths using linear equations. Shorter routes earn higher scores and money for more supplies. Start with one free turbo boost and shell protection.", BLACK),
            ]
            self._intro_paragraphs = []
            y = 108
            for value, colour in paragraphs:
                for line in wrap_text(value, INTRO_FONT, 536):
                    self._intro_paragraphs.append((INTRO_FONT.render(line, True, colour), (370, y)))
                    y += 29
                y += 14
            instructions = [
                "To play: Click the equation box, type the equation of a line and press Enter. If the line meets the turtle, use arrow keys to follow it.",
                "Clicking the equation box pauses activity on the beach. G shows or hides the grid; M opens the menu.",
                "T activates turbo boost for 3 seconds. Hold S to hide in the shell; release S to move. A shell protection is only used up when a hawk hits.",
            ]
            self._intro_instructions = []
            row = 12
            for value in instructions:
                for line in wrap_text(value, SMALL_FONT, 840):
                    self._intro_instructions.append((SMALL_FONT.render(line, True, DARK_GREEN), row))
                    row += SMALL_FONT.get_linesize()+2
                row += 6
            self._intro_strip_y = max(480, y+10)
            self._intro_strip_height = row+6
            self._intro_card_height = max(730, self._intro_strip_y+self._intro_strip_height+94)
            # Egg/nest are static; the hatchling is still animated each frame.
            self._intro_egg = pygame.Surface((760, 580), pygame.SRCALPHA)
            story_nest_and_egg(self._intro_egg)
            self._intro_key = key
        self.intro_card = pygame.Rect(WIDTH//2-470, (HEIGHT-self._intro_card_height)//2,
                                     940, self._intro_card_height)
        self.intro_start = pygame.Rect(self.intro_card.right-326, self.intro_card.bottom-70, 294, 44)

    def draw_intro(self):
        SCREEN.fill((233,215,174)); self.intro_layout(); card=self.intro_card
        pygame.draw.rect(SCREEN,(251,247,231),card,border_radius=20)
        title=BIG_FONT.render("Journey to the Ocean",True,DARK_GREEN)
        SCREEN.blit(title,title.get_rect(midtop=(card.centerx,card.y+25)))
        source=self._intro_egg.copy()
        story_draw_hatchling(source,self.intro_time)
        art=pygame.transform.smoothscale(source.subsurface((270,260,450,300)),(342,228))
        SCREEN.blit(art,(card.x+12,card.y+183))
        for text, position in self._intro_paragraphs:
            SCREEN.blit(text, (card.x+position[0], card.y+position[1]))
        strip=pygame.Rect(card.x+32,card.y+self._intro_strip_y,876,self._intro_strip_height)
        pygame.draw.rect(SCREEN,(225,239,220),strip,border_radius=10)
        for text, dy in self._intro_instructions:
            SCREEN.blit(text,(strip.x+18,strip.y+dy))
        pygame.draw.rect(SCREEN,(28,128,95),self.intro_start,border_radius=7)
        label=FONT.render("Help the hatchling",True,WHITE)
        SCREEN.blit(label,label.get_rect(center=self.intro_start.center))

    def draw_happy_ocean(self,rect):
        """Same front-facing hatchling: now safe, smiling and swimming."""
        w,h=rect.size;t=self.celebration_time
        scene=pygame.Surface((w,h)).convert()
        for y in range(h):
            f=y/max(1,h-1);colour=tuple(round(a+(b-a)*f) for a,b in zip((99,199,200),(29,123,164)))
            pygame.draw.line(scene,colour,(0,y),(w,y))
        for band in range(6):
            points=[(x,round(12+band*43+5*math.sin(x/78-t*.9+band))) for x in range(0,w+8,8)]
            pygame.draw.lines(scene,(136-band*10,220-band*9,215-band*7),False,points,2)
        cx=round(w*.46+math.sin(t*.5)*w*.045);cy=round(h*.59+math.sin(t*1.4)*3)
        sprite=self.story_sprite(t,True)
        sprite=pygame.transform.smoothscale(sprite,(139,177))
        scene.blit(sprite,sprite.get_rect(center=(cx,cy)))
        SCREEN.blit(scene,rect)

    @staticmethod
    def make_hawk_schedule():
        intro=2;red_intro=random.choice((5,6))
        first=random.choice(("black","white"));schedule=[]
        for level,total in enumerate(HAWK_COUNTS):
            red=3 if level==9 else int(level>=red_intro)
            if level<intro:black=white=0
            elif level==intro:black,white=(1,0) if first=="black" else (0,1)
            elif level==intro+1:black,white=(2,1) if first=="black" else (1,2)
            else:
                black=schedule[-1].count("black");white=schedule[-1].count("white")
                special=max(black+white,round(total*.25))
                while black+white<special:
                    if random.random()<.5:black+=1
                    else:white+=1
            if level==8:
                black=schedule[7].count("black")+random.randint(2,4)
                white=schedule[7].count("white")
            if level==9:
                special=random.randint(6,8)
                black=random.randint(2,special-2);white=special-black
            kinds=["brown"]*(total-red-black-white)+["black"]*black+["white"]*white+["red"]*red
            random.shuffle(kinds);schedule.append(kinds)
        return schedule

    def start_level(self):
        retry=self.inventory_level==self.level and self.state=="game_over"
        if retry:self.seen_props=set(self.round_seen_before)
        else:self.round_seen_before=set(self.seen_props)
        if self.inventory_level==self.level and self.state=="game_over":
            self.turbo_charges,self.shell_charges,self.turbo_remaining,self.circle_charges,self.super_charges=self.round_inventory
        else:
            self.inventory_level=self.level
            self.round_inventory=(self.turbo_charges,self.shell_charges,self.turbo_remaining,self.circle_charges,self.super_charges)
        self.shell_remaining=0.0;self.shell_fold=0.0;self.shell_grace=0.0;self.shell_contacts=set()
        configure_view((WIDTH,HEIGHT),round_side=self.direction_schedule[self.level])
        self.round_bounds=(-BASE_X,BASE_X,-BASE_Y,BASE_Y)
        # Keep the journey deck: every new prop appears before the deck repeats.
        self.shell_held=False;self.traps=[];self.circle_entry=False;self.circle_confirm=None
        self.circle_inputs=[InputBox(0,0,62,32) for _ in range(3)]
        for box in self.circle_inputs:box.text=""
        self.obstacle_seed=random.randrange(100000000)
        self._view_cache={}
        self.fullscreen_requested=False
        self.show_grid = True
        self.grid_intro_remaining = 4.0
        self.scene_time=0.0
        self.state = "playing"
        self.menu_visible = False
        self.manual_pause = False
        self.line_input.active = False
        self.lines = []
        self.line_input.text = ""
        self.message = "Draw a line through the turtle to reach safety."
        self.message_colour = BLACK

        self.randomize_platforms()
        self.obstacles = self.make_obstacles(1)
        self.object_polygons = [list(poly) for poly in self.obstacles]

        self.turtle_x,self.turtle_y=self.start_point
        self.previous_turtle_position=self.start_point
        self.turtle_angle={"left":0.0,"right":180.0,"bottom":90.0,"top":-90.0}[self.start_side]
        self.previous_turtle_angle=self.turtle_angle
        self.trail_points=[]
        self.trail_surface=pygame.Surface((WIDTH,HEIGHT),pygame.SRCALPHA)
        self.trail_last=self.start_point
        self.actual_distance = 0.0
        self.crawl_phase = 0.0
        self.celebration_time = 0.0
        self.turtle_path = "sand"
        self.turtle_line = None
        self.falling = False
        self.rock_surface_y = None
        self.fall_old_y = self.turtle_y
        self.fall_facing_angle = self.turtle_angle
        self.vertical_move_key = None
        self.cached_switch_line = None
        self.cached_switch_point = None
        self.switch_grace = 0.0

        self.hawks = self.make_hawks(HAWK_COUNTS[self.level])
        self.make_beach_background()
        self.make_rock_art()
        self.minimum_distance = self.calculate_minimum_distance()
        self.spawn_crab()

    def randomize_platforms(self):
        self.start_side=self.direction_schedule[self.level]
        self.finish_side={"left":"right","right":"left","top":"bottom","bottom":"top"}[self.start_side]
        limit=int(BASE_Y-6)
        a=float(random.randint(-limit,limit));b=float(random.choice([v for v in range(-limit,limit+1) if abs(v-a)>=4]))
        if self.level==9:
            tangent_extent=BASE_Y if self.finish_side in ("left","right") else BASE_X
            b=max(-tangent_extent+11,min(tangent_extent-11,b))
        if self.start_side in ("left","right"):
            sign=1 if self.start_side=="right" else -1
            self.start_point=(sign*(BASE_X-(8.0 if self.level<3 else 5.5)),a)
            self.goal_point=(-sign*(BASE_X-(8.0 if self.level<3 else 4.5)),b)
        else:
            sign=1 if self.start_side=="top" else -1
            self.start_point=(a,sign*(BASE_Y-(4.5 if self.level<3 else 3.5)))
            self.goal_point=(b,-sign*(BASE_Y-2.5))
        if self.level==0:self.start_point=(-BASE_X+9.0,-10.5);self.goal_point=(BASE_X-10.0,8.5)
        self.ui_on_right=self.start_point[0]<=0
        sign=1 if self.ui_on_right else -1
        self.ui_inner=BASE_X-(16.5 if self.level>=6 else 10.5)
        self.ui_floor=-BASE_Y if self.level>=6 else (5.5 if self.level>=4 else 11.5)
        gx,gy=self.goal_point
        if self.level==9 and self.finish_side in ("top","bottom"):
            low=-BASE_X+(0 if self.ui_on_right else 16.5)+23.5
            high=BASE_X-(16.5 if self.ui_on_right else 0)-23.5
            gx=max(low,min(high,gx));b=gx
        if sign*gx>self.ui_inner-2.5 and gy>self.ui_floor-2.5:
            if self.finish_side in ("left","right") and self.level<9:
                # Keep the destination across the beach, below the corner HUD,
                # rather than pulling it halfway towards the centre.
                gy=-9.5
            elif self.level>=6:gx=sign*(self.ui_inner-2.5)
            else:gy=self.ui_floor-2.5
        # Starting supplies make the inventory HUD visible from round one.
        if self.level<9 and self.finish_side in ("left","right") and sign*gx>BASE_X-12 and gy>5.5:
            gy=3.5
        self.goal_point=(gx,gy)
        self.shore_depth=(abs(self.goal_point[0]) if self.finish_side in ("left","right") else abs(self.goal_point[1]))-.5
        self.gate_tangent=b
        self.start_y=self.start_point[1];self.finish_y=self.goal_point[1]
        # Retained for older path helpers; active movement begins on sand.
        self.start_x1=self.start_point[0]-1;self.start_x2=self.start_point[0]+1
        self.finish_x1=self.goal_point[0]-1.5;self.finish_x2=self.goal_point[0]+1.5

    def clear_of_controls(self,cx,cy,rx=0.0,ry=0.0):
        sign=1 if self.ui_on_right else -1
        return sign*cx+rx<self.ui_inner or cy+ry<self.ui_floor

    @staticmethod
    def make_obstacle_schedule():
        kinds=["beach_ball","bucket","hat","flipflops","surfboard","parasol","bottle","conch","seaweed","starfish"]
        deck=kinds[:];random.shuffle(deck)
        schedule=[["boulder"]*random.choice((1,1,2))]
        for level in range(1,9):
            entry=["boulder"]*random.choice((1,1,2))
            count=random.choice((1,1,2))+(1 if level>=5 and random.random()<.5 else 0)
            for _ in range(count):
                if not deck:deck=kinds[:];random.shuffle(deck)
                # Never duplicate a prop within a round, including at deck boundaries.
                available=[k for k in deck if k not in entry]
                if not available:break
                kind=available[-1];deck.remove(kind);entry.append(kind)
            schedule.append(entry)
        schedule.append(["surfboard","surfboard","starfish",random.choice(("seaweed","conch"))])
        return schedule

    def make_obstacles(self, count):
        self.collision_masks=None
        if self.level==9:return self.make_final_obstacles()
        self.obstacle_kinds=list(self.obstacle_schedule[self.level])
        all_props=["beach_ball","bucket","hat","flipflops","surfboard","parasol","bottle","conch","seaweed","starfish"]
        unseen=[kind for kind in all_props if kind not in self.seen_props];random.shuffle(unseen)
        used=set()
        for i,kind in enumerate(self.obstacle_kinds):
            if kind=="boulder":continue
            if kind=="towel":
                if kind not in self.seen_props or not unseen:continue
                kind=unseen.pop()
            elif kind in unseen:unseen.remove(kind)
            elif unseen:kind=unseen.pop()
            if kind in used:
                alternatives=[k for k in all_props if k not in used]
                kind=random.choice(alternatives)
            self.obstacle_kinds[i]=kind;used.add(kind)
        # Block the straight crossing in most rounds: y = start_y for lateral
        # journeys, x = start_x for vertical journeys. Keep diagonals open where practical.
        horizontal=self.start_side in ("left","right")
        axis=0 if horizontal else 1
        tangent=1-axis
        self.block_straight_route=random.random()<.85
        if self.block_straight_route and "boulder" not in self.obstacle_kinds:
            self.obstacle_kinds[0]="boulder"
        blocker_index=self.obstacle_kinds.index("boulder") if self.block_straight_route else None
        self.keep_direct_route=random.random()<.72
        shapes=[];placed=[]
        for index,kind in enumerate(self.obstacle_kinds):
            for attempt in range(800):
                if attempt==400:self.keep_direct_route=False
                factor=(.65*1.2 if kind=="bottle" else 1.35*2 if kind=="surfboard" else 2*1.15 if kind=="parasol" else 1.0)*OBJECT_SCALE
                rx=random.uniform(2.0,3.0)*factor;ry=random.uniform(2.0,3.0)*factor
                if kind=="towel":rx=3.4*OBJECT_SCALE;ry=4.4*OBJECT_SCALE
                if index==blocker_index:
                    progress=random.uniform(.25,.85)
                    centre=[0.0,0.0]
                    centre[axis]=self.start_point[axis]+progress*(self.goal_point[axis]-self.start_point[axis])
                    # Offset away from the destination's cross-axis coordinate,
                    # leaving room for a diagonal on the other side of the rock.
                    away=1 if self.start_point[tangent]>self.goal_point[tangent] else -1
                    centre[tangent]=self.start_point[tangent]+away*(ry if horizontal else rx)*random.uniform(.10,.35)
                    cx,cy=centre
                    if attempt==400:self.keep_direct_route=False
                else:
                    cx=random.uniform(-BASE_X+5,BASE_X-5);cy=random.uniform(-BASE_Y+5,BASE_Y-5)
                    if kind=="towel" or (index>1 and random.random()<.65):cx=random.choice((-1,1))*random.uniform(BASE_X*.53,BASE_X*.80)
                radius=max(rx,ry)*1.1
                if abs(cx)+rx>BASE_X-1.5 or abs(cy)+ry>BASE_Y-1.5:continue
                if not self.clear_of_controls(cx,cy,rx*1.2,ry*1.2):continue
                if self.keep_direct_route and distance_to_segment(cx,cy,*self.start_point,*self.goal_point)<radius+1.15:continue
                if (math.dist((cx,cy),self.start_point)>radius+3 and math.dist((cx,cy),self.goal_point)>radius+3
                        and all(math.hypot(cx-x,cy-y)>radius+r+2 for x,y,r in placed)):
                    break
            else:
                self.obstacle_kinds=self.obstacle_kinds[:index];break
            phase=random.uniform(0,math.tau);points=[]
            for i in range(40):
                t=math.tau*i/40;f=1+.06*math.sin(3*t+phase)+.03*math.cos(5*t)
                points.append((cx+rx*math.cos(t)*f,cy+ry*math.sin(t)*f))
            shapes.append(points);placed.append((cx,cy,radius))
        self.seen_props.update(k for k in self.obstacle_kinds if k!="boulder")
        return shapes

    def make_final_obstacles(self):
        """Colourful surfboards flank a clear opening to the ocean; no shoreline rocks."""
        rng=random.Random(self.obstacle_seed)
        horizontal=self.finish_side in ("left","right")
        sign=1 if self.finish_side in ("right","top") else -1
        def point(depth,tangent):return (sign*depth,tangent) if horizontal else (tangent,sign*depth)
        centre=self.gate_tangent;gap=3.2*OBJECT_SCALE;depth=self.shore_depth-.95*OBJECT_SCALE
        self.final_gate=(depth,centre,gap)
        kinds=[];shapes=[]
        def ellipse(kind,d,t,normal_radius,tangent_radius,rough=False):
            normal_radius*=OBJECT_SCALE;tangent_radius*=OBJECT_SCALE
            phase=random.Random(self.obstacle_seed+round(d*37)+round(t*101)).uniform(0,math.tau);poly=[]
            for i in range(40):
                a=math.tau*i/40
                f=1+.055*math.sin(a*3+phase)+.025*math.cos(a*5) if rough else 1
                poly.append(point(d+normal_radius*math.cos(a)*f,t+tangent_radius*math.sin(a)*f))
            kinds.append(kind);shapes.append(poly)
        # Large longboards flank the opening, lying parallel to the shore.
        for side in (-1,1):ellipse("surfboard",depth-5.7*OBJECT_SCALE,centre+side*(gap/2+9.6*OBJECT_SCALE),3.4,8.6)
        ball_rng = random.Random(self.obstacle_seed + 599)
        depth_extent = BASE_X if horizontal else BASE_Y
        tangent_extent = BASE_Y if horizontal else BASE_X

        for _ in range(40):
            ball_depth = ball_rng.uniform(
                -depth_extent + 4, self.shore_depth - 16
            )
            ball_tangent = ball_rng.uniform(
                -tangent_extent + 4, tangent_extent - 4
            )
            bx, by = point(ball_depth, ball_tangent)

            if math.dist((bx, by), self.start_point) < 5:
                continue
            if not self.clear_of_controls(bx, by, 2, 2):
                continue

            ellipse("beach_ball", ball_depth, ball_tangent, 1.3, 1.3)
            break
        self.obstacle_kinds=kinds
        return shapes

    def final_minimum_distance(self,end_point=None):
        """Find a navigable route through the actual final-round silhouettes."""
        start=self.start_point;goal=self.goal_point if end_point is None else end_point
        a=tuple(round(v) for v in start);b=tuple(round(v) for v in goal)
        frontier=[(0,a)];cost={a:0.0}
        while frontier:
            _,node=heapq.heappop(frontier)
            if node==b:return cost[node]+math.dist(start,a)+math.dist(goal,b)
            for dx,dy in ((1,0),(-1,0),(0,1),(0,-1),(1,1),(-1,1),(1,-1),(-1,-1)):
                nxt=(node[0]+dx,node[1]+dy)
                if not (X_MIN+.6<nxt[0]<X_MAX-.6 and Y_MIN+.6<nxt[1]<Y_MAX-.6):continue
                if not self.point_clear_of_obstacles(nxt) or not self.route_segment_is_clear(node,nxt):continue
                value=cost[node]+math.hypot(dx,dy)
                if value<cost.get(nxt,float("inf")):
                    cost[nxt]=value;heapq.heappush(frontier,(value+math.dist(nxt,b),nxt))
        return math.dist(start,goal)

    def point_clear_of_obstacles(self, point, clearance=PATH_CLEARANCE):
        px, py = point
        if getattr(self, "collision_masks", None) is not None:
            sx, sy = graph_to_screen(px, py)
            radius = max(1, math.ceil(clearance * SCALE))
            if radius not in self.contact_circles:
                circle = pygame.Surface((radius * 2 + 1, radius * 2 + 1), pygame.SRCALPHA)
                pygame.draw.circle(circle, WHITE, (radius, radius), radius)
                self.contact_circles[radius] = pygame.mask.from_surface(circle)
            circle = self.contact_circles[radius]
            for mask, (left, top) in self.collision_masks:
                if mask.overlap(circle, (sx - radius - left, sy - radius - top)) is not None:
                    return False
            return True
        for polygon in self.obstacles:
            if point_in_polygon(px, py, polygon):
                return False
            for i, (x1, y1) in enumerate(polygon):
                x2, y2 = polygon[(i + 1) % len(polygon)]
                if distance_to_segment(px, py, x1, y1, x2, y2) < clearance:
                    return False
        return True

    def route_segment_is_clear(self, start, end):
        """Check a proposed shortest-path segment at fine intervals."""
        distance = math.dist(start, end)
        steps = max(2, int(math.ceil(distance / 0.12)))
        for i in range(1, steps):
            t = i / steps
            point = (start[0] + (end[0] - start[0]) * t,
                     start[1] + (end[1] - start[1]) * t)
            if not self.point_clear_of_obstacles(point):
                return False
        return True

    def calculate_minimum_distance(self,end_point=None):
        """Approximate the shortest safe route with a visibility graph."""
        if self.level==9:return self.final_minimum_distance(end_point)
        start=self.start_point
        if end_point is not None:goal=end_point
        else:
            gx,gy=self.goal_point;dx,dy=start[0]-gx,start[1]-gy
            factor=1/math.sqrt((dx/(1.35*OBJECT_SCALE))**2+(dy/(1.05*OBJECT_SCALE))**2)
            goal=(gx+dx*factor,gy+dy*factor)
        nodes = [start, goal]

        # Offset each corner away from its obstacle by the turtle's clearance.
        for polygon in self.obstacles:
            cx = sum(x for x, _ in polygon) / len(polygon)
            cy = sum(y for _, y in polygon) / len(polygon)
            for x, y in polygon[::max(1, len(polygon) // 10)]:
                vx, vy = x - cx, y - cy
                length = math.hypot(vx, vy) or 1.0
                candidate = (x + vx / length * PATH_CLEARANCE * 1.35,
                             y + vy / length * PATH_CLEARANCE * 1.35)
                if (X_MIN < candidate[0] < X_MAX
                        and Y_MIN < candidate[1] < Y_MAX
                        and self.point_clear_of_obstacles(candidate, PATH_CLEARANCE * 0.98)):
                    nodes.append(candidate)

        graph = [[] for _ in nodes]
        for i in range(len(nodes)):
            for j in range(i + 1, len(nodes)):
                if self.route_segment_is_clear(nodes[i], nodes[j]):
                    weight = math.dist(nodes[i], nodes[j])
                    graph[i].append((j, weight))
                    graph[j].append((i, weight))

        distances = [float("inf")] * len(nodes)
        visited = [False] * len(nodes)
        distances[0] = 0.0
        for _ in nodes:
            current = min((i for i in range(len(nodes)) if not visited[i]),
                          key=lambda i: distances[i], default=None)
            if current is None or math.isinf(distances[current]):
                break
            if current == 1:
                break
            visited[current] = True
            for neighbour, weight in graph[current]:
                distances[neighbour] = min(distances[neighbour],
                                           distances[current] + weight)

        # A route around compact central obstacles should always exist. This
        # conservative fallback prevents scoring from failing unexpectedly.
        if math.isinf(distances[1]):
            return math.dist(start, goal)
        return distances[1]

    def finish_level_score(self):
        # Compare routes to the point actually reached, not an arbitrary point
        # inside the destination. Distance is in world units, independent of pixels.
        self.minimum_distance=min(self.actual_distance,self.calculate_minimum_distance((self.turtle_x,self.turtle_y)))
        travelled = max(self.actual_distance, self.minimum_distance)
        self.last_level_score = max(0.0, min(100.0,
                                    100.0 * self.minimum_distance / max(travelled,1e-9)))
        if len(self.level_scores) == self.level:
            self.level_scores.append(self.last_level_score)
        else:
            self.level_scores[self.level] = self.last_level_score
        self.message = "The turtle reached the safe zone!"
        self.message_colour = DARK_GREEN
        self.celebration_time = 0.0

    def make_hawks(self, count):
        hawks = []

        # Every hawk line passes within this many graph units of the origin.
        # This keeps central capture opportunities possible without forcing
        # all hawks through the exact origin.
        for i,kind in enumerate(self.hawk_schedule[self.level]):
            # Reject entire flight lines near the nest, so it remains safe all round.
            # Three graph units leaves room for the hawk drawing as well as its body.
            for _ in range(1000):
                angle = random.uniform(math.radians(15), math.radians(165))
                dx, dy = math.cos(angle), math.sin(angle)
                nx, ny = -dy, dx
                offset = random.uniform(-6.5, 6.5)
                A, B, C = nx, ny, -offset
                distance_from_nest = abs(A * self.turtle_x + B * self.turtle_y + C)
                if distance_from_nest >= (7.0 if kind=="red" else 3.3)*OBJECT_SCALE:
                    break
            else:
                # A central vertical flight line is always clear of the edge nest.
                A,B,C=(1.0,0.0,0.0) if abs(self.turtle_x)>=abs(self.turtle_y) else (0.0,1.0,0.0)
            line = Line(A, B, C, "hawk path")

            # Spread starting positions but bias many toward the central region.
            if i < max(1, count // 2):
                t = random.uniform(-8, 8)
            else:
                t = random.uniform(-16, 16)

            endpoints = line.visible_endpoints()
            if len(endpoints) == 2:
                limits = sorted(x * line.dx + y * line.dy for x, y in endpoints)
                margin = HAWK_BEAK_REACH*(2.4 if kind=="red" else 1.0)*OBJECT_SCALE + .1
                if limits[1] - limits[0] > 2 * margin:
                    t = max(limits[0] + margin, min(limits[1] - margin, t))
            speed=random.uniform(*{"brown":(4.2,6.2),"white":(4.2,6.2),"black":(11.5,13.5),"red":(14.0,16.0)}[kind])*MOVEMENT_SCALE
            direction = random.choice((-1, 1))
            hawks.append(Hawk(line, t, direction, speed, kind))

        return hawks

    def add_line(self):
        text = self.line_input.text.strip()
        if not text:
            return
        try:
            line = parse_linear_equation(text)
        except Exception as exc:
            self.message = str(exc) if str(exc) else "Enter a valid linear equation."
            self.message_colour = RED
            return

        self.lines.append(line)
        self.line_input.text = ""
        if len(self.lines) == 1:
            self.message = "Line added."
        else:
            self.message = (
                "Line added. At a highlighted intersection, release the current "
                "arrow key or press a new arrow key to switch lines."
            )
        self.message_colour = BLUE

    def delete_latest_line(self):
        if not self.lines:   
            self.message_colour = GREY
            return

        removed = self.lines.pop()

        if self.turtle_line is removed:
            self.turtle_line = None
            self.turtle_path = "sand"
            self.falling = False
            self.message = "Path erased. Draw a line through the turtle to continue."
            self.message_colour = BLUE
        else:
            self.message = "Most recent line erased."
            self.message_colour = BLACK

    def nearest_usable_intersection(self):
        """Find the closest valid intersection with ANY other student line."""
        if not self.lines or self.falling or self.turtle_path == "finish":
            return None, None

        best_line = None
        best_point = None
        best_distance = float("inf")

        for candidate in self.lines:
            if candidate is self.turtle_line:
                continue

            p = None

            if self.turtle_path == "start":
                if abs(candidate.A) < 1e-9:
                    continue
                ix = -(candidate.B * self.start_y + candidate.C) / candidate.A
                if self.start_x1 <= ix <= self.start_x2:
                    p = (ix, self.start_y)

            elif self.turtle_path == "sand":
                # Closest point permits recovery after deleting the current path.
                denominator = candidate.A ** 2 + candidate.B ** 2
                offset = candidate.signed_value(self.turtle_x, self.turtle_y) / denominator
                p = (self.turtle_x - candidate.A * offset,
                     self.turtle_y - candidate.B * offset)
                if not self.point_clear_of_obstacles(p):
                    p = None

            elif self.turtle_line is not None:
                p = self.turtle_line.intersection(candidate)
                if p is not None:
                    if not (X_MIN <= p[0] <= X_MAX and Y_MIN <= p[1] <= Y_MAX):
                        p = None

            if p is None:
                continue

            distance = math.dist((self.turtle_x, self.turtle_y), p)
            if distance < best_distance:
                best_distance = distance
                best_line = candidate
                best_point = p

        return best_line, best_point

    def near_intersection(self):
        """Return the nearest intersection only while the turtle is in contact with it."""
        line, p = self.nearest_usable_intersection()
        if line is None or p is None:
            return None, None
        if math.dist((self.turtle_x, self.turtle_y), p) <= INTERSECTION_TOL:
            return line, p
        return None, None

    def direction_for_key(self, line, key_name):
        """Return a unit direction along line that matches the arrow key."""
        dx, dy = line.dx, line.dy
        eps = 1e-9

        if key_name == "right":
            if abs(dx) < eps:
                return None
            if dx < 0:
                dx, dy = -dx, -dy
        elif key_name == "left":
            if abs(dx) < eps:
                return None
            if dx > 0:
                dx, dy = -dx, -dy
        elif key_name == "up":
            if abs(dy) < eps:
                return None
            if dy < 0:
                dx, dy = -dx, -dy
        elif key_name == "down":
            if abs(dy) < eps:
                return None
            if dy > 0:
                dx, dy = -dx, -dy
        else:
            return None

        return dx, dy

    def switch_to_line(self, key_name):
        line, p = self.near_intersection()
        if line is None or p is None:
            return False

        direction = self.direction_for_key(line, key_name)
        if direction is None:
            return False

        if self.crab_blocks(p):
            return False
        self.turtle_x, self.turtle_y = p
        dx, dy = direction
        self.turtle_line = line
        self.turtle_path = "line"
        self.turtle_angle = math.degrees(math.atan2(dy, dx))
        self.message = "Path changed."
        self.message_colour = BLUE
        return True

    def horizontal_start_line(self):
        """Return the newest horizontal line matching the start ledge."""
        for line in reversed(self.lines):
            if (abs(line.A) < 1e-9 and abs(line.B) > 1e-9
                    and abs(line.y_at(0) - self.start_y) < 1e-6):
                return line
        return None

    def move_until_rock(self, start, end):
        """Sweep the turtle's radius along movement to prevent tunnelling."""
        length = math.dist(start, end)
        steps = max(1, math.ceil(length / 0.06))
        last = start
        for i in range(1, steps + 1):
            t = i / steps
            candidate = (start[0] + (end[0] - start[0]) * t,
                         start[1] + (end[1] - start[1]) * t)
            if (not self.point_clear_of_obstacles(candidate, TURTLE_RADIUS)
                    or self.crab_blocks(candidate)):
                if self.crab_blocks(candidate):
                    self.message = "The crab is in the way. Wait or take another path."
                    self.message_colour = BLUE
                return last
            last = candidate
        return end

    def rock_supports(self, x, y):
        """Check whether solid rock is directly beneath the turtle's feet."""
        return (not self.point_clear_of_obstacles((x, y - 0.08), TURTLE_RADIUS)
                and self.point_clear_of_obstacles((x, y + 0.08), TURTLE_RADIUS))

    def move_turtle(self, dt, keys):
        if self.falling:
            return

        if self.shell_remaining>0 or self.shell_fold>.01:return
        # Account for a boost ending part-way through this simulation step.
        amount = TURTLE_SPEED * (dt+(TURBO_MULTIPLIER-1)*min(dt,self.turbo_remaining))
        old_x, old_y = self.turtle_x, self.turtle_y

        pressed = []
        if keys[pygame.K_UP]:
            pressed.append("up")
        if keys[pygame.K_RIGHT]:
            pressed.append("right")
        if keys[pygame.K_DOWN]:
            pressed.append("down")
        if keys[pygame.K_LEFT]:
            pressed.append("left")

        if not pressed:
            return

        # Holding an arrow does not switch paths automatically.
        # A switch requires a fresh KEYDOWN while touching an intersection.
        # The player can release and press the same arrow again, or press a
        # different arrow, to choose the intersecting path.

        if self.turtle_line is not None:
            direction = None
            for key_name in pressed:
                direction = self.direction_for_key(self.turtle_line, key_name)
                if direction is not None:
                    break

            if direction is None:
                return

            dx, dy = direction
            # Clip distance along the LINE, rather than clamping axes independently.
            # At a boundary both coordinates stop, including for diagonal paths.
            for value, velocity, low, high in ((old_x,dx,X_MIN,X_MAX),(old_y,dy,Y_MIN,Y_MAX)):
                if velocity > 1e-9:
                    amount = min(amount, max(0.0,(high-value)/velocity))
                elif velocity < -1e-9:
                    amount = min(amount, max(0.0,(low-value)/velocity))
            self.turtle_x, self.turtle_y = self.move_until_rock(
                (old_x, old_y), (old_x + dx * amount, old_y + dy * amount))
            self.turtle_angle = math.degrees(math.atan2(dy, dx))
            self.check_line_arrival(old_x, old_y)

    def goal_contains(self, point):
        x,y=point
        if self.level==9:
            depth=(-x if self.finish_side=="left" else x if self.finish_side=="right" else y if self.finish_side=="top" else -y)
            return depth>=self.shore_depth+.25
        gx,gy=self.goal_point
        return ((x-gx)/(1.35*OBJECT_SCALE))**2+((y-gy)/(1.05*OBJECT_SCALE))**2<=1

    def check_line_arrival(self, old_x, old_y):
        if self.goal_contains((self.turtle_x,self.turtle_y)):
            self.turtle_path="finish";self.turtle_line=None

    def check_hawk_collision(self):
        if self.state!="playing":return
        touching=set()
        previous=self.previous_turtle_position
        for hawk in self.hawks:
            if not hawk.touches_turtle(previous,(self.turtle_x,self.turtle_y),self.turtle_angle,self.previous_turtle_angle,self.shell_fold):continue
            touching.add(hawk)
            if hawk in self.shell_contacts:continue
            if self.shell_held and self.shell_charges>0:
                if hawk not in self.shell_contacts:
                    if self.shell_charges<=0:
                        self.game_over("No shell protections left — a hawk caught the turtle!");return
                    self.shell_charges-=1
                    self.message="Hawk hit blocked! One shell protection used."
                    self.message_colour=DARK_GREEN
            else:
                self.game_over("A hawk caught the turtle!");return
        self.shell_contacts=touching
        if self.shell_charges==0:self.shell_held=False;self.shell_remaining=0.0;self.shell_fold=0.0

    def check_obstacle_collision(self):
        """Rocks are solid, not lethal; movement is clamped before contact."""
        return

    def check_finish(self):
        if self.state != "playing":
            return
        # Reaching any part of the physical SAFE ZONE completes the round.
        # Do not require the player to move an additional unit along the ledge.
        if self.turtle_path == "finish":
            self.finish_level_score()
            if self.level == len(HAWK_COUNTS) - 1:
                self.state = "won"
            else:
                self.state = "level_complete"

    def game_over(self, reason):
        self.state = "game_over"
        self.message = reason
        self.message_colour = RED

    def update(self, dt):
        if self.state=="intro":self.intro_time+=dt;return
        if self.state=="playing" and (self.manual_pause or self.menu_visible or self.line_input.active or self.circle_entry):return
        if self.grid_intro_remaining > 0:
            self.grid_intro_remaining = max(0.0, self.grid_intro_remaining - dt)
            if self.grid_intro_remaining == 0:
                self.show_grid = False
        if self.state == "won":
            self.celebration_time += dt
            return
        if self.state == "level_complete":
            return
        if self.state != "playing":
            return

        self.scene_time+=dt
        self.update_shell(dt)
        old_position = (self.turtle_x, self.turtle_y)
        self.previous_turtle_position=old_position
        self.previous_turtle_angle=self.turtle_angle
        self.update_crab(dt)

        for hawk in self.hawks:
            self.update_trapped_hawk(hawk,dt)
        self.capture_hawks()

        keys = pygame.key.get_pressed()
        if not self.line_input.active:
            self.move_turtle(dt, keys)
        else:
            self.vertical_move_key = None
        travelled = math.dist(old_position, (self.turtle_x, self.turtle_y))
        self.actual_distance += travelled
        self.turbo_remaining=max(0.0,self.turbo_remaining-dt)
        self.record_trail(old_position,(self.turtle_x,self.turtle_y))
        # Effort, rather than distance, drives the flippers: the hatchling keeps
        # scrambling when a rock, crab, or beach boundary blocks its progress.
        if self.shell_fold<.01 and any(keys[key] for key in (pygame.K_LEFT,pygame.K_RIGHT,pygame.K_UP,pygame.K_DOWN)):
            self.crawl_phase = (self.crawl_phase + dt * math.tau * 2.8) % math.tau
        # Reaching safety takes priority and immediately opens the results screen.
        self.check_finish()
        if self.state != "playing":
            return
        self.check_obstacle_collision()
        self.check_hawk_collision()

    def layout_controls(self):
        global PANEL_LEFT
        place_right=self.ui_on_right
        PANEL_LEFT=WIDTH-218 if place_right else 4
        self.corner_x=PANEL_LEFT
        self.line_input.rect.update(PANEL_LEFT+8,34,190,38)
        self.menu_toggle=pygame.Rect(PANEL_LEFT+8,82,100,32)
        self.pause_button=pygame.Rect(PANEL_LEFT+116,82,82,32)
        self.circle_button=pygame.Rect(PANEL_LEFT+8,294,190,32)
        self.exit_fullscreen_button=pygame.Rect(PANEL_LEFT+8,122,190,32)
        self.menu_rect=pygame.Rect(WIDTH//2-350,max(94,HEIGHT//2-370),700,740)
        self.close_menu=pygame.Rect(self.menu_rect.left+28,self.menu_rect.bottom-56,334,40)
        self.fullscreen_button=pygame.Rect(self.menu_rect.right-288,self.menu_rect.bottom-56,260,40)
        self.retry_button.rect.update(WIDTH//2-70,HEIGHT//2+70,140,44)
        self.next_button.rect.update(WIDTH//2-80,HEIGHT//2+230,160,44)
        self.restart_button.rect.update(WIDTH//2-90,HEIGHT-100,180,44)
        self.next_button.text="Visit shop" if self.level in (3,5,7) else "Next Level"

    def handle_event(self,event):
        self.layout_controls()
        if event.type==pygame.KEYUP and event.key==pygame.K_s:
            self.shell_held=False;self.shell_remaining=0.0;self.shell_fold=0.0;self.shell_contacts=set()
            return
        if event.type==pygame.WINDOWFOCUSLOST:
            self.shell_held=False;self.shell_remaining=0.0;self.shell_fold=0.0
        key=event.key if event.type==pygame.KEYDOWN else None
        click=event.type==pygame.MOUSEBUTTONDOWN and event.button==1
        if click and getattr(self,"fullscreen",False) and self.exit_fullscreen_button.collidepoint(event.pos):
            self.fullscreen_requested=True;return
        if self.state=="intro":
            self.intro_layout()
            if key in (pygame.K_RETURN,pygame.K_ESCAPE) or (click and self.intro_start.collidepoint(event.pos)):
                self.state="playing";self.grid_intro_remaining=4.0
            return
        if self.state=="shop":self.handle_shop_event(event);return
        if self.state=="playing" and click and self.pause_button.collidepoint(event.pos):
            self.manual_pause=not self.manual_pause;return
        if click and self.menu_visible and self.fullscreen_button.collidepoint(event.pos):
            self.fullscreen_requested=True;self.menu_visible=False;return
        if key==pygame.K_g:
            self.show_grid=not self.show_grid;self.grid_intro_remaining=0;return
        if self.state!="playing":
            if self.state=="game_over" and (key==pygame.K_RETURN or self.retry_button.clicked(event)):
                self.start_level()
            elif self.state=="level_complete" and (key==pygame.K_RETURN or self.next_button.clicked(event)):
                if self.level in (3,5,7):self.enter_shop(self.level+1)
                else:self.level+=1;self.start_level()
            elif self.state=="won" and (key==pygame.K_RETURN or self.restart_button.clicked(event)):
                self.level=0;self.level_scores=[];self.last_level_score=None
                self.new_journey();self.crab_seed=random.randrange(100000000);self.start_level();self.state="intro";self.intro_time=0.0
            return
        if self.circle_unlocked and self.state=="playing" and (self.circle_entry or key==pygame.K_c or (click and self.circle_button.collidepoint(event.pos))):
            self.handle_circle_event(event);return
        if key==pygame.K_ESCAPE and self.line_input.active:
            self.line_input.active=False
            self.message="Equation entry closed. Press Enter to type again."
            return
        toggle=key==pygame.K_m or (key==pygame.K_ESCAPE and self.menu_visible) or (click and not self.menu_visible and self.menu_toggle.collidepoint(event.pos))
        close=click and self.menu_visible and self.close_menu.collidepoint(event.pos)
        if toggle or close:
            self.menu_visible=not self.menu_visible if toggle else False
            self.line_input.active=False
            return
        if click and self.line_input.rect.collidepoint(event.pos):
            self.line_input.active=True;self.menu_visible=False;return
        if self.line_input.active:
            submitted,erased=self.line_input.handle_event(event)
            if key==pygame.K_RETURN:submitted=True
            if erased:self.delete_latest_line()
            if submitted:
                count=len(self.lines);self.add_line()
                if len(self.lines)>count:
                    self.line_input.active=False
                    self.menu_visible=False
            return
        if key==pygame.K_RETURN:
            self.line_input.active=True;self.menu_visible=False;return
        if self.manual_pause or self.menu_visible:return
        if key in (pygame.K_t,pygame.K_s):
            if not getattr(event,"repeat",False):self.activate_powerup("turbo" if key==pygame.K_t else "shell")
            return
        if key==pygame.K_BACKSPACE:self.delete_latest_line();return
        if key in (pygame.K_UP,pygame.K_RIGHT,pygame.K_DOWN,pygame.K_LEFT):
            self.switch_to_line({pygame.K_UP:"up",pygame.K_RIGHT:"right",pygame.K_DOWN:"down",pygame.K_LEFT:"left"}[key])

    # -------------------- DRAWING --------------------
    def make_beach_background(self):
        key=(self.level,850)
        if getattr(self,"_sand_key",None)!=key:
            self._sand_tile=pygame.transform.rotate(make_sand(42+self.level),90)
            self._sand_key=key
        original=self._sand_tile
        tile_size=original.get_width()
        self.beach=pygame.Surface((WIDTH,HEIGHT)).convert()
        for x in range(0,WIDTH,tile_size):
            for y in range(0,HEIGHT,tile_size):
                tile=pygame.transform.flip(original,(x//tile_size)%2==1,(y//tile_size)%2==1)
                self.beach.blit(tile,(x,y))
        rng=random.Random(1800+self.level)
        for _ in range(70):
            self.draw_pebble(self.beach,rng.randrange(WIDTH),rng.randrange(HEIGHT),rng.choice((2,2,3)),rng)
        for _ in range(28):
            x,y=rng.randrange(10,WIDTH-10),rng.randrange(10,HEIGHT-10)
            pygame.draw.ellipse(self.beach,(193,166,121),(x,y+2,6,4))
            pygame.draw.polygon(self.beach,(241,227,199),[(x,y+3),(x+2,y-2),(x+6,y),(x+5,y+3)])

    def draw_beach_goal(self):
        if self.level==9:
            # Build the shore in world coordinates, on whichever side is the goal.
            t=getattr(self,"scene_time",0.0)
            sign=1 if self.finish_side in ("right","top") else -1
            horizontal=self.finish_side in ("left","right")
            def point(depth,tangent):
                return graph_to_screen(sign*depth,tangent) if horizontal else graph_to_screen(tangent,sign*depth)
            extent=(HEIGHT if horizontal else WIDTH)/(2*SCALE)
            boundary=(WIDTH if horizontal else HEIGHT)/(2*SCALE)
            tangents=[-extent+2*extent*i/120 for i in range(121)]
            shore=[self.shore_depth+.18*math.sin(v*.8)+.12*math.sin(t*1.2+v*.3) for v in tangents]
            wet=[point(d-.45,v) for d,v in zip(shore,tangents)]
            pygame.draw.polygon(SCREEN,(188,174,136),wet+[point(boundary,extent),point(boundary,-extent)])
            for band in range(36):
                f=band/35
                pts=[point(d+(boundary-d)*f,v) for d,v in zip(shore,tangents)]
                colour=tuple(round(a+(b-a)*f) for a,b in zip((126,190,174),(23,104,145)))
                pygame.draw.polygon(SCREEN,colour,pts+[point(boundary,extent),point(boundary,-extent)])
            return
        gx,gy=self.goal_point;cx,cy=graph_to_screen(gx,gy)
        # A shallow sheltered hollow, clearly visible inside the fixed playing area.
        inside=pygame.Rect(0,0,round(SCALE*2.7*OBJECT_SCALE),round(SCALE*2.1*OBJECT_SCALE));inside.center=(cx,cy)
        for ring in range(10):
            r=inside.inflate(-ring*2,-ring*1.4)
            if r.width>0 and r.height>0:pygame.draw.ellipse(SCREEN,(93+ring*2,73+ring*2,43+ring),r)


    def draw_platforms(self):
        # The nest is a subtle depression beneath the starting turtle.
        sx,sy=graph_to_screen(*self.start_point)
        rim=pygame.Surface((62,42),pygame.SRCALPHA)
        for inset in range(8):pygame.draw.ellipse(rim,(139,109,66,8),(inset,inset,62-2*inset,42-2*inset))
        rim=pygame.transform.smoothscale(rim,(round(62*OBJECT_SCALE),round(42*OBJECT_SCALE)))
        SCREEN.blit(rim,rim.get_rect(center=(sx,sy)))

    def stamp_trail(self, point):
        x,y,angle=point
        sx,sy=graph_to_screen(x,y)
        forward=pygame.Vector2(math.cos(angle),-math.sin(angle))
        normal=pygame.Vector2(-forward.y,forward.x)
        centre=pygame.Vector2(sx,sy)
        for sign in (-1,1):
            p=centre+normal*(sign*SCALE*OBJECT_SCALE*.29)
            a=p-forward*SCALE*OBJECT_SCALE*.14;b=p+forward*SCALE*OBJECT_SCALE*.10+normal*(sign*SCALE*OBJECT_SCALE*.08)
            pygame.draw.line(self.trail_surface,(147,109,61,65),a,b,max(1,round(SCALE*OBJECT_SCALE*.085)))
            pygame.draw.aaline(self.trail_surface,(250,229,177,95),a-normal,b-normal)
        # A faint belly track connects the alternating flipper marks.
        pygame.draw.line(self.trail_surface,(166,130,79,28),centre-forward*SCALE*OBJECT_SCALE*.1,centre+forward*SCALE*OBJECT_SCALE*.1,max(1,round(SCALE*OBJECT_SCALE*.12)))

    def record_trail(self, start, end):
        if math.dist(start,end)<1e-8:return
        distance=math.dist(self.trail_last,end)
        if distance<.20:return
        count=max(1,int(distance/.20));origin=self.trail_last
        angle=math.atan2(end[1]-start[1],end[0]-start[0])
        for index in range(1,count+1):
            f=index/count
            point=(origin[0]+(end[0]-origin[0])*f,origin[1]+(end[1]-origin[1])*f,angle)
            self.trail_points.append(point);self.stamp_trail(point)
        self.trail_last=end

    def rebuild_trail(self):
        self.trail_surface=pygame.Surface((WIDTH,HEIGHT),pygame.SRCALPHA)
        for point in self.trail_points:self.stamp_trail(point)

    def draw_trail(self):
        SCREEN.blit(self.trail_surface,(0,0))

    def draw_grid(self):
        SCREEN.blit(self.beach,(0,0))
        self.draw_beach_goal()
        if not (self.show_grid or self.line_input.active or self.circle_entry):return
        key = (WIDTH, HEIGHT, GRAPH_W, GRAPH_SIZE, GRAPH_LEFT, GRAPH_TOP,
               SCALE, X_MIN, X_MAX, Y_MIN, Y_MAX, GREY, id(TINY_FONT))
        if getattr(self, "_grid_key", None) != key:
            grid=pygame.Surface((GRAPH_W,GRAPH_SIZE),pygame.SRCALPHA)
            for x in range(math.ceil(X_MIN),math.floor(X_MAX)+1):
                sx,_=graph_to_screen(x,0)
                pygame.draw.line(grid,(108,93,61,48),(sx-GRAPH_LEFT,0),(sx-GRAPH_LEFT,GRAPH_SIZE))
            for y in range(math.ceil(Y_MIN),math.floor(Y_MAX)+1):
                _,sy=graph_to_screen(0,y)
                pygame.draw.line(grid,(108,93,61,48),(0,sy-GRAPH_TOP),(GRAPH_W,sy-GRAPH_TOP))
            sx,sy=graph_to_screen(0,0)
            pygame.draw.line(grid,(74,78,58,130),(sx-GRAPH_LEFT,0),(sx-GRAPH_LEFT,GRAPH_SIZE),2)
            pygame.draw.line(grid,(74,78,58,130),(0,sy-GRAPH_TOP),(GRAPH_W,sy-GRAPH_TOP),2)
            labels = []
            ticks = []
            for x in range(math.ceil(X_MIN/5)*5, math.floor(X_MAX/5)*5+1, 5):
                if x:
                    px, py = graph_to_screen(x, 0)
                    ticks.append(((px, py-3), (px, py+3)))
                    text = TINY_FONT.render(str(x), True, GREY)
                    labels.append((text, (max(4, min(WIDTH-text.get_width()-4, px+3)), py+4)))
            for y in range(math.ceil(Y_MIN/5)*5, math.floor(Y_MAX/5)*5+1, 5):
                if y:
                    px, py = graph_to_screen(0, y)
                    ticks.append(((px-3, py), (px+3, py)))
                    text = TINY_FONT.render(str(y), True, GREY)
                    labels.append((text, (px+5, max(4, min(HEIGHT-text.get_height()-4, py-7)))))
            self._grid_key = key
            self._grid_art, self._grid_labels, self._grid_ticks = grid, labels, ticks
        SCREEN.blit(self._grid_art, (GRAPH_LEFT, GRAPH_TOP))
        for (start, end), (text, position) in zip(self._grid_ticks, self._grid_labels):
            pygame.draw.line(SCREEN, GREY, start, end, 2)
            SCREEN.blit(text, position)

    def spawn_crab(self):
        self.crabs=[]
        self.crab_radius=.57*OBJECT_SCALE
        rng=random.Random(self.crab_seed+self.level)
        count=self.crab_schedule[self.level]
        if not count:return
        for index in range(count):
            for _ in range(400):
                pos=pygame.Vector2(rng.uniform(-BASE_X+6,BASE_X-6),rng.uniform(-BASE_Y+5,BASE_Y-5))
                if (self.clear_of_controls(pos.x,pos.y,1.2,1.2) and self.point_clear_of_obstacles(pos,self.crab_radius+.2)
                        and math.dist(pos,(self.turtle_x,self.turtle_y))>4
                        and all(pos.distance_to(c["pos"])>2.5 for c in self.crabs)):
                    self.crabs.append(dict(pos=pos,heading=rng.uniform(0,math.tau),
                        timer=rng.uniform(.7,2.6),walking=True,phase=0.0,
                        speed=rng.uniform(1,2),rng=random.Random(rng.randrange(100000))))
                    break

    def crab_blocks(self, point):
        return any(self.crab_turtle_overlap(point,c["pos"]) for c in getattr(self,"crabs",[]))

    @staticmethod
    def crab_turtle_overlap(point, crab_position):
        # Crab art is 35 × 32 pixels at BASE_SCALE; its body occupies
        # roughly 19 × 13 pixels. Include nearby legs without a wide halo.
        rx=.57*OBJECT_SCALE+TURTLE_RADIUS
        ry=.40*OBJECT_SCALE+TURTLE_RADIUS
        return ((point[0]-crab_position[0])/rx)**2+((point[1]-crab_position[1])/ry)**2<1

    def update_crab(self, dt):
        for crab in self.crabs:
            rng=crab["rng"];crab["timer"]-=dt
            if crab["timer"]<=0:
                crab["walking"]=not crab["walking"]
                crab["timer"]=rng.uniform(.7,2.8) if crab["walking"] else rng.uniform(.6,3.0)
                crab["heading"]=rng.uniform(0,math.tau);crab["speed"]=rng.uniform(1,2)
            if not crab["walking"]:continue
            next_pos=crab["pos"]+pygame.Vector2(math.cos(crab["heading"]),math.sin(crab["heading"]))*crab["speed"]*dt
            if (self.clear_of_controls(next_pos.x,next_pos.y,1.2,1.2) and abs(next_pos.x)<BASE_X-2 and abs(next_pos.y)<MIN_VISIBLE_Y-1.5
                    and self.point_clear_of_obstacles(next_pos,self.crab_radius+.1)
                    and not self.crab_turtle_overlap((self.turtle_x,self.turtle_y),next_pos)
                    and all(other is crab or next_pos.distance_to(other["pos"])>self.crab_radius*2+.1 for other in self.crabs)):
                crab["pos"]=next_pos;crab["phase"]+=dt*13
            else:
                crab["walking"]=False;crab["timer"]=rng.uniform(.2,.8)

    def draw_crab(self):
        for crab in self.crabs:
            self.crab=crab["pos"];self.crab_walking=crab["walking"];self.crab_phase=crab["phase"]
            self.draw_one_crab()

    def draw_one_crab(self):
        if self.crab is None:
            return
        sprite = pygame.Surface((48, 44), pygame.SRCALPHA)
        pygame.draw.ellipse(sprite, (75, 49, 22, 45), (7, 22, 35, 15))
        step = math.sin(self.crab_phase) * 2 if self.crab_walking else 0
        for side in (-1, 1):
            for leg in range(4):
                root = (24 + side * 9, 21 + leg * 3)
                joint = (round(24 + side * 17), round(17 + leg * 5 + step * (-1) ** leg))
                tip = (24 + side * 21, round(20 + leg * 5 - step * (-1) ** leg))
                pygame.draw.lines(sprite, (133, 64, 32), False, [root, joint, tip], 2)
            pygame.draw.lines(sprite, (177, 88, 41), False, [(24 + side * 8, 22), (24 + side * 16, 13), (24 + side * 14, 8)], 3)
            pygame.draw.circle(sprite, (204, 117, 55), (24 + side * 14, 8), 5)
            pygame.draw.line(sprite, (81, 48, 28), (24 + side * 14, 3), (24 + side * 14, 7), 2)
        for inset in range(6):
            pygame.draw.ellipse(sprite, (169 + inset * 7, 81 + inset * 6, 37 + inset * 3),
                                (12 + inset, 17 + inset // 2, 25 - inset * 2, 17 - inset))
        for x in (19, 29):
            pygame.draw.line(sprite, (149, 82, 38), (x, 20), (x, 13), 2)
            pygame.draw.circle(sprite, (32, 31, 22), (x, 12), 2)
            pygame.draw.circle(sprite, (242, 230, 191), (x, 11), 1)
        sx, sy = graph_to_screen(self.crab.x, self.crab.y)
        zoom=OBJECT_SCALE*SCALE/BASE_SCALE
        sprite=pygame.transform.smoothscale(sprite,(round(35*zoom),round(32*zoom)))
        SCREEN.blit(sprite, sprite.get_rect(center=(sx, sy)))

    def make_rock_art(self):
        """Cache material and soft shadows once; geometry still matches solid obstacles."""
        self.rock_art = []
        rng = random.Random(900 + self.level)
        for index, polygon in enumerate(self.obstacles):
            points = [graph_to_screen(x, y) for x, y in polygon]
            kind = self.obstacle_kinds[index]
            if kind != "boulder":
                painters = {"bucket": improved_bucket, "seaweed": improved_seaweed,
                            "hat": hat, "flipflops": flipflops, "surfboard": surfboard,
                            "parasol": parasol, "bottle": bottle, "conch": conch,
                            "starfish": starfish, "beach_ball": beach_ball,"towel":towel}
                tile = pygame.Surface((360, 360), pygame.SRCALPHA)
                if kind=="surfboard" and self.level==9:
                    festival_board(tile,random.Random(self.obstacle_seed+index*67),0 if self.finish_side in ("left","right") else 90,variant=index%3)
                else:painters[kind](tile,rng)
                crop = tile.get_bounding_rect().clip(tile.get_rect())
                tile = tile.subsurface(crop).copy()
                span = max(max(x for x,y in points)-min(x for x,y in points),
                           max(y for x,y in points)-min(y for x,y in points))
                factor = span / max(tile.get_size())
                image = pygame.transform.smoothscale(tile, (max(1, round(tile.get_width()*factor)),
                                                           max(1, round(tile.get_height()*factor))))
                centre = (round(sum(x for x,y in points)/len(points)), round(sum(y for x,y in points)/len(points)))
                position = image.get_rect(center=centre).topleft
                self.rock_art.append((pygame.Surface((1,1),pygame.SRCALPHA), image, position))
                continue
            left = min(x for x, y in points) - 14
            top = min(y for x, y in points) - 14
            width = max(x for x, y in points) - left + 15
            height = max(y for x, y in points) - top + 15
            local = [(x - left, y - top) for x, y in points]
            shape = pygame.Surface((width, height), pygame.SRCALPHA)
            pygame.draw.polygon(shape, (255, 255, 255), local)
            mask = pygame.mask.from_surface(shape)
            rock = pygame.Surface((width, height), pygame.SRCALPHA)
            # A consistent mineral colour per rock, lit from the upper left.
            kind = self.obstacle_kinds[index]
            base = rng.choice(((151, 143, 126), (158, 151, 135), (143, 142, 132)))
            ball_colours = ((247, 244, 226), (226, 52, 48), (246, 132, 36),
                            (248, 212, 44), (41, 126, 212), (58, 169, 90))
            cx = sum(x for x, y in local) / len(local)
            cy = sum(y for x, y in local) / len(local)
            rx, ry = max(1, (width - 28) / 2), max(1, (height - 28) / 2)
            rock.lock()
            for y in range(height):
                for x in range(width):
                    if not mask.get_at((x, y)):
                        continue
                    nx, ny = (x - cx) / rx, (y - cy) / ry
                    dome = max(0, 1 - .65 * nx * nx - .65 * ny * ny)
                    light = 17 * dome - 16 * nx - 20 * ny - 9
                    grain = rng.uniform(-3.5, 3.5)
                    variation = 2 * math.sin(x * .12 + y * .08) + grain

                    colour = tuple(max(0, min(255, round(c + light + variation))) for c in base)
                    if kind == "beach_ball":
                        # Six sewn panels wrap a softly lit sphere; crisp seams, curved shading.
                        radius = max(rx, ry)
                        bx, by = (x - cx) / radius, (y - cy) / radius
                        z = math.sqrt(max(0, 1 - bx * bx - by * by))
                        theta = (math.atan2(by + .18, bx + .12) + math.tau) % math.tau
                        panel = theta / math.tau * 6
                        colour_base = ball_colours[int(panel) % 6]
                        brightness = .58 + .42 * max(0, -.36 * bx - .42 * by + .83 * z)
                        colour = tuple(min(255, round(c * brightness)) for c in colour_base)
                        if min(panel % 1, 1 - panel % 1) < .008:
                            colour = tuple(round(c * brightness) for c in (236, 232, 212))
                        gloss = max(0, 1 - ((bx + .34) ** 2 + (by + .38) ** 2) / .11) ** 3
                        colour = tuple(round(c + (255 - c) * gloss * .58) for c in colour)
                    rock.set_at((x, y), (*colour, 255))
            rock.unlock()
            if kind == "beach_ball":
                cap = (round(cx - rx * .12), round(cy - ry * .18))
                pygame.draw.circle(rock, (228, 225, 210), cap, 5)
                pygame.draw.circle(rock, (251, 248, 233), (cap[0] - 1, cap[1] - 1), 3)
            else:
                pygame.gfxdraw.aapolygon(rock, local, tuple(c - 22 for c in base))
            shadow = pygame.Surface((width, height), pygame.SRCALPHA)
            pygame.draw.polygon(shadow, (67, 49, 26, 62), [(x + 5, y + 7) for x, y in local])
            shadow = pygame.transform.smoothscale(
                pygame.transform.smoothscale(shadow, (max(1, width // 7), max(1, height // 7))),
                (width, height))
            self.rock_art.append((shadow, rock, (left, top)))
        self.collision_masks = []
        self.contact_circles = {}
        silhouettes = []
        for shadow, image, (left, top) in self.rock_art:
            mask = pygame.mask.from_surface(image, 170)
            self.collision_masks.append((mask, (left, top)))
            for component in mask.connected_components(12):
                outline = component.outline()
                if len(outline) < 3:
                    continue
                step = max(1, len(outline) // 24)
                outline = outline[::step]
                silhouettes.append([(X_MIN + (left+x-GRAPH_LEFT)/SCALE,
                                     Y_MAX - (top+y-GRAPH_TOP)/SCALE) for x,y in outline])
        self.obstacles = silhouettes
    @staticmethod
    def draw_pebble(surface, x, y, radius, rng):
        colour = rng.choice(((155, 148, 131), (180, 165, 139), (139, 142, 132), (201, 187, 160)))
        pygame.draw.ellipse(surface, (184, 157, 112), (x - radius + 1, y - radius // 2 + 2, radius * 2, radius + 2))
        pygame.draw.ellipse(surface, tuple(c - 13 for c in colour), (x - radius, y - radius // 2, radius * 2, radius + 1))
        pygame.draw.ellipse(surface, colour, (x - radius, y - radius // 2, radius * 2 - 1, max(2, radius)))
        pygame.draw.aaline(surface, tuple(min(255, c + 22) for c in colour),
                           (x - radius + 1, y - radius // 2), (x, y - radius // 2))

    def draw_obstacles(self):
        for shadow, rock, position in self.rock_art:
            SCREEN.blit(shadow, position)
            SCREEN.blit(rock, position)

    def draw_student_lines(self):
        highlighted_line, highlighted_point = self.near_intersection()
        occupied=self.turtle_line
        if occupied is None:
            occupied=next((line for line in reversed(self.lines)
                           if abs(line.signed_value(self.turtle_x,self.turtle_y))/math.hypot(line.A,line.B)<.12),None)
        for line in self.lines:
            pts = line.visible_endpoints()
            if len(pts) != 2:
                continue
            p1 = graph_to_screen(*pts[0])
            p2 = graph_to_screen(*pts[1])

            colour = BLUE
            width = 3
            if line is occupied:
                colour=(255,235,0);width=5
            elif line is highlighted_line:
                colour=(30,80,190);width=4

            pygame.draw.line(SCREEN, colour, p1, p2, width)

        if highlighted_point is not None:
            sx, sy = graph_to_screen(*highlighted_point)
            pygame.draw.circle(SCREEN, YELLOW, (sx, sy), 9, 3)

    def make_turtle_surface(self, size_multiplier=1.0, gait_phase=None, tuck=0.0):
        """The original green hatchling, with independently paddling flippers."""
        w=max(18,int(1.65*SCALE*size_multiplier*OBJECT_SCALE))
        h=max(12,int(1.05*SCALE*size_multiplier*OBJECT_SCALE))
        surf=pygame.Surface((w,h),pygame.SRCALPHA)
        if tuck<.98:
            root=pygame.Vector2(w*.18,h*.5)
            tail=[root+(pygame.Vector2(x,y)-root)*(1-tuck) for x,y in ((w*.12,h*.5),(0,h*.38),(0,h*.62))]
            pygame.draw.polygon(surf,DARK_GREEN,[(round(v.x),round(v.y)) for v in tail])
        if gait_phase is None:
            foot_r = max(2, int(h * 0.13))
            for fx, fy in ((0.28, 0.16), (0.28, 0.84), (0.65, 0.16), (0.65, 0.84)):
                pygame.draw.circle(surf, DARK_GREEN, (int(w * fx), int(h * fy)), foot_r)
                pygame.draw.circle(surf, BLACK, (int(w * fx), int(h * fy)), foot_r, 1)
        else:
            # Opposite front/rear flippers stroke together in an eager alternating scramble.
            # Render limbs at triple resolution to keep their changing outlines smooth.
            limbs=pygame.Surface((w*3,h*3),pygame.SRCALPHA)
            for front in (False,True):
                for side in (-1,1):
                    offset=0 if (front and side==-1) or (not front and side==1) else math.pi
                    stroke=math.sin(gait_phase+offset)+.16*math.sin(3*gait_phase+offset+.7)
                    hip=pygame.Vector2(w*(.61 if front else .28),h*(.36 if side==-1 else .64))
                    angle=side*math.radians((64 if front else 122)+stroke*36)
                    length=w*(.25 if front else .20)*(1-tuck)
                    tip=hip+pygame.Vector2(math.cos(angle),math.sin(angle))*length
                    tip.y=max(1.0,min(h-2.0,tip.y))
                    tip.x=max(1.0,min(w-2.0,tip.x))
                    direction=tip-hip
                    if direction.length_squared()==0:continue
                    normal=pygame.Vector2(-direction.y,direction.x).normalize()
                    width=h*(.105 if front else .09)*(1-tuck)
                    mid=hip+direction*.55
                    points=[hip+normal*width*.65,mid+normal*width,tip+normal*width*.22,
                            tip-normal*width*.22,mid-normal*width*.7,hip-normal*width*.65]
                    points=[(round(v.x*3),round(v.y*3)) for v in points]
                    pygame.draw.polygon(limbs,(20,79,43),points)
                    pygame.draw.lines(limbs,(41,130,69),False,points[:3],max(1,round(size_multiplier*2)))
            surf.blit(pygame.transform.smoothscale(limbs,(w,h)),(0,0))

        def draw_head():
            if tuck>=.98:return
            head_r=max(1,round(max(3,int(h*.22))*(1-tuck)))
            head=(round(w*(.84-.23*tuck)),h//2)
            pygame.draw.circle(surf,DARK_GREEN,head,head_r)
            pygame.draw.circle(surf,BLACK,head,head_r,max(1,int(size_multiplier)))
            if tuck<.65:
                eye=(head[0]+max(1,head_r//3),head[1]-max(1,head_r//3))
                pygame.draw.circle(surf,WHITE,eye,max(1,head_r//4))
                pygame.draw.circle(surf,BLACK,eye,max(1,head_r//7))
        if tuck>.001:draw_head()
        shell=pygame.Rect(int(w*.12),int(h*.18),int(w*.65),int(h*.64))
        pygame.draw.ellipse(surf,GREEN,shell)
        pygame.draw.ellipse(surf,BLACK,shell,max(1,int(size_multiplier)))
        inner=shell.inflate(-max(4,int(w*.16)),-max(3,int(h*.20)))
        if inner.width>0 and inner.height>0:
            pygame.draw.ellipse(surf,DARK_GREEN,inner,max(1,int(size_multiplier)))
        if tuck<=.001:draw_head()
        return surf

    def turtle_art(self):
        if self.shell_fold>.001:
            sprite=self.make_turtle_surface(gait_phase=self.crawl_phase,tuck=self.shell_fold)
            return sprite,make_ground_shadow(sprite,opacity=77,softness=2,size_factor=.94)
        # Cache poses and their matching shadows, regenerating only after a size change.
        cache_key=round(SCALE,4)
        if getattr(self,"_crawl_cache_key",None)!=cache_key:
            self._crawl_cache_key=cache_key
            self._crawl_frames=[]
            for frame in range(36):
                sprite=self.make_turtle_surface(gait_phase=math.tau*frame/36)
                shadow=make_ground_shadow(sprite,opacity=77,softness=2,size_factor=.94)
                self._crawl_frames.append((sprite,shadow))
        frame=int(self.crawl_phase/math.tau*len(self._crawl_frames))%len(self._crawl_frames)
        return self._crawl_frames[frame]

    def draw_turtle_shadow(self):
        sx,sy=graph_to_screen(self.turtle_x,self.turtle_y)
        _,shadow=self.turtle_art()
        rotated=pygame.transform.rotozoom(shadow,self.turtle_angle+1.3*math.sin(self.crawl_phase),1)
        rect=rotated.get_rect(center=(sx+3,sy+4))
        SCREEN.blit(rotated,rect)
        return rect

    def draw_turtle(self):
        sx,sy=graph_to_screen(self.turtle_x,self.turtle_y)
        if self.turbo_remaining>0 and not self.shell_held:
            direction=pygame.Vector2(math.cos(math.radians(self.turtle_angle)),-math.sin(math.radians(self.turtle_angle)))
            normal=pygame.Vector2(-direction.y,direction.x)
            for offset in (-5,0,5):
                end=pygame.Vector2(sx,sy)-direction*SCALE*.9*OBJECT_SCALE+normal*offset
                start=end-direction*(9+3*math.sin(self.scene_time*12+offset))
                pygame.draw.line(SCREEN,(238,175,40),start,end,2)
        sprite,_=self.turtle_art()
        rotated=pygame.transform.rotozoom(sprite,self.turtle_angle+1.3*math.sin(self.crawl_phase),1)
        SCREEN.blit(rotated,rotated.get_rect(center=(sx,sy)))

    def draw_score_history(self, card, start_y, mirror_left=False):
        """Align labels left and score values right in two balanced columns."""
        if mirror_left:
            label_width = max(SMALL_FONT.size(f"Round {n}:")[0] for n in range(1, 11))
            value_width = SMALL_FONT.size("100.0 / 100")[0]
            column_width = label_width + 14 + value_width
            gap = 70
            first_x = card.centerx - gap//2 - column_width
            second_x = card.centerx + gap//2
            for index, score in enumerate(self.level_scores):
                x = first_x if index < 5 else second_x
                y = start_y + (index % 5)*30
                label = SMALL_FONT.render(f"Round {index+1}:", True, PURPLE)
                value = SMALL_FONT.render(f"{score:.1f} / 100", True, PURPLE)
                SCREEN.blit(label, (x, y))
                SCREEN.blit(value, (x+column_width-value.get_width(), y))
            return
        # Preserve the intermediate results-card layout.
        for index, round_score in enumerate(self.level_scores):
            column, row = index//5, index%5
            x = card.x+55+column*(card.width//2)
            result = SMALL_FONT.render(f"Round {index+1}: {round_score:.1f} / 100", True, PURPLE)
            SCREEN.blit(result, (x, start_y+row*30))

    def draw_round_score_card(self):
        """Static, unmistakable results screen shown after rounds 1–9."""
        card = pygame.Rect(WIDTH//2-235,HEIGHT//2-210,470,420)
        pygame.draw.rect(SCREEN, WHITE, card, border_radius=14)
        pygame.draw.rect(SCREEN, DARK_GREEN, card, 4, border_radius=14)

        heading = BIG_FONT.render("ROUND COMPLETE", True, DARK_GREEN)
        SCREEN.blit(heading, (card.centerx - heading.get_width() // 2, card.y + 20))

        current_round = len(self.level_scores)
        score_banner = pygame.Rect(card.x + 25, card.y + 65, card.width - 50, 64)
        pygame.draw.rect(SCREEN, BLUE, score_banner, border_radius=10)
        pygame.draw.rect(SCREEN, BLACK, score_banner, 2, border_radius=10)
        score_text = FONT.render(
            f"ROUND {current_round} SCORE: {self.last_level_score:.1f} / 100",
            True, WHITE,
        )
        SCREEN.blit(score_text, score_text.get_rect(center=score_banner.center))

        details = SMALL_FONT.render(
            f"Estimated shortest: {self.minimum_distance:.1f}   Travelled: {self.actual_distance:.1f}",
            True, BLACK,
        )
        SCREEN.blit(details, (card.centerx - details.get_width() // 2, card.y + 145))

        history_title = FONT.render("Scores so far", True, BLACK)
        SCREEN.blit(history_title, (card.centerx - history_title.get_width() // 2, card.y + 185))
        self.draw_score_history(card, card.y + 225)

        if self.level<3:
            note=TINY_FONT.render("Good scores earn shop money after round 4.",True,DARK_GREEN)
            SCREEN.blit(note,note.get_rect(midtop=(card.centerx,card.y+355)))
        prompt="Press Enter to visit the supply shop" if self.level in (3,5,7) else "Press Enter or click Next Level"
        continue_text = SMALL_FONT.render(prompt, True, GREY)
        SCREEN.blit(continue_text, (card.centerx - continue_text.get_width() // 2, card.y + 380))

    def draw_final_celebration(self):
        average=sum(self.level_scores)/len(self.level_scores)
        card=pygame.Rect(WIDTH//2-390,42,780,700)
        pygame.draw.rect(SCREEN,(250,247,232),card,border_radius=14)
        pygame.draw.rect(SCREEN,(39,125,116),card,3,border_radius=14)
        heading=TITLE_FONT.render("You guided the hatchling safely to the ocean!",True,DARK_GREEN)
        SCREEN.blit(heading,heading.get_rect(midtop=(card.centerx,card.y+20)))
        banner=pygame.Rect(card.x+45,card.y+62,690,58)
        pygame.draw.rect(SCREEN,(34,123,155),banner,border_radius=9)
        label=TITLE_FONT.render(f"AVERAGE SCORE: {average:.1f} / 100",True,WHITE)
        SCREEN.blit(label,label.get_rect(center=banner.center))
        self.draw_happy_ocean(pygame.Rect(card.x+28,card.y+142,724,250))
        title=FONT.render("Your scores for each round",True,BLACK)
        SCREEN.blit(title,title.get_rect(midtop=(card.centerx,card.y+411)))
        self.draw_score_history(card, card.y + 451, mirror_left=True)
        note="Brilliant math skills — and one very happy turtle!" if average>=95 else "A happy ending to this epic journey across the beach."
        label=SMALL_FONT.render(note,True,DARK_GREEN)
        SCREEN.blit(label,label.get_rect(midtop=(card.centerx,card.y+613)))
        label=SMALL_FONT.render("Press Enter or click Restart Game",True,GREY)
        SCREEN.blit(label,label.get_rect(midtop=(card.centerx,card.y+654)))

    def draw_score_card(self):
        if self.last_level_score is None:
            return
        if self.state == "level_complete":
            self.draw_round_score_card()
        elif self.state == "won":
            self.draw_final_celebration()

    def draw_panel(self):
        self.layout_controls()
        x=self.corner_x+8
        label="Type an equation" if not self.line_input.active else "Enter to draw"
        if self.line_input.active and self.message_colour==RED:
            label="Check equation"
          
        SCREEN.blit(EQUATION_LABEL_FONT.render(label,True,RED if self.line_input.active and self.message_colour==RED else BLACK),(x,5))
        self.line_input.draw()
        self.draw_power_hud()
        pygame.draw.rect(SCREEN,(238,225,192),self.pause_button,border_radius=6)
        pause_text=TINY_FONT.render("Resume" if self.manual_pause else "Pause",True,DARK_GREEN)
        SCREEN.blit(pause_text,pause_text.get_rect(center=self.pause_button.center))
        if self.circle_unlocked:
            pygame.draw.rect(SCREEN,(224,235,226),self.circle_button,border_radius=6)
            label=TINY_FONT.render("Place circle [C]",True,DARK_GREEN)
            SCREEN.blit(label,label.get_rect(center=self.circle_button.center))
        SCREEN.blit(TINY_FONT.render("G: show / hide grid",True,DARK_GREEN),(x,HEIGHT-23))
        if not self.menu_visible:
            pygame.draw.rect(SCREEN,(243,233,204),self.menu_toggle,border_radius=6)
            text=TINY_FONT.render("Show menu",True,DARK_GREEN)
            SCREEN.blit(text,text.get_rect(center=self.menu_toggle.center))
            return
        card=self.menu_rect
        shadow=pygame.Surface((card.width+16,card.height+16),pygame.SRCALPHA)
        pygame.draw.rect(shadow,(55,49,32,55),shadow.get_rect(),border_radius=16)
        SCREEN.blit(shadow,(card.x+5,card.y+7))
        pygame.draw.rect(SCREEN,(248,243,226),card,border_radius=14)
        pygame.draw.rect(SCREEN,(139,152,111),card,2,border_radius=14)
        left=card.x+28
        def label(text,y,font=SMALL_FONT,colour=BLACK):
            SCREEN.blit(font.render(text,True,colour),(left,card.y+y))
        def paragraph(text,y,colour=BLACK,font=SMALL_FONT,limit=3):
            for part in wrap_text(text,font,card.width-56)[:limit]:
                label(part,y,font,colour);y+=font.get_linesize()+3
            return y
        label("Journey to the Ocean",20,TITLE_FONT,DARK_GREEN)
        n=len(self.obstacle_kinds);c=len(self.crabs)
        summary=f"Round {self.level+1} of 10 | {len(self.hawks)} hawks | {n} obstacle"+("s" if n!=1 else "")
        if c:summary+=f" | {c} crab"+("s" if c!=1 else "")
        label(summary+" | Paused",60,SMALL_FONT,BLUE)
        pygame.draw.line(SCREEN,(209,199,169),(left,card.y+89),(card.right-28,card.y+89))
        label("Draw a path",106,FONT)
        paragraph("Click the equation box or press Enter. Draw a line through the turtle, then use the arrow keys to follow it.",142)
        label("Examples: y = 2x + 3     x = 5     y = −2",198,SMALL_FONT,GREY)
        label("Controls",234,FONT)
        paragraph("At an intersection, release and press an arrow key to choose a different path.",270)
        paragraph("G: grid. T: turbo. S: shell protection. Backspace: erase the newest line. F11: fullscreen. Equation entry pauses the beach; submitting or closing it resumes play.",325)
        paragraph("Solid objects and crabs block the turtle. Avoid the hawks. The grid appears automatically while you enter an equation.",398)
        target="Reach the ocean on the "+{"left":"left","right":"right","top":"top","bottom":"bottom"}[self.finish_side]+" side." if self.level==9 else f"Reach the sheltered sand hollow near ({self.goal_point[0]:.0f}, {self.goal_point[1]:.0f})."
        paragraph(target,450,DARK_GREEN)
        paragraph("Start with one free turbo boost and shell protection. Higher scores earn money for more supplies after rounds 4, 6 and 8.",486,DARK_GREEN,TINY_FONT,2)
        label("Status",530,FONT)
        paragraph(f"Turtle: ({self.turtle_x:.2f}, {self.turtle_y:.2f}). "+self.message,566,self.message_colour,TINY_FONT,3)
        label("Hold S: shell. C: ordinary / super circle. T: turbo boost." if self.circle_unlocked else "Turbo lasts for 3 seconds. Shell protections are only used up when a hawk strikes",635,TINY_FONT,DARK_GREEN)
        pygame.draw.rect(SCREEN,(225,233,202),self.close_menu,border_radius=7)
        text=SMALL_FONT.render("Return to the beach [M]",True,DARK_GREEN)
        SCREEN.blit(text,text.get_rect(center=self.close_menu.center))
        pygame.draw.rect(SCREEN,(220,230,218),self.fullscreen_button,border_radius=7)
        caption="Return to window [F11]" if getattr(self,"fullscreen",False) else "Full screen [F11]"
        text=SMALL_FONT.render(caption,True,DARK_GREEN)
        SCREEN.blit(text,text.get_rect(center=self.fullscreen_button.center))

    def draw_beach_world(self):
        SCREEN.fill((237,221,183));self.draw_grid();self.draw_platforms();self.draw_trail();self.draw_traps(include_preview=False)
        # Ground shadows precede animals and solid props, so they never paint over them.
        for hawk in self.hawks:hawk.draw_shadow()
        self.draw_turtle_shadow()
        self.draw_student_lines();self.draw_obstacles();self.draw_crab()
        for hawk in self.hawks:hawk.draw()
        self.draw_turtle()
    def draw(self):
        self.layout_controls()
        if self.state != "playing":
            self._paused_world = None
            self._paused_world_key = None
        if self.state=="intro":self.draw_intro();return
        if self.state=="won":
            for band in range(32):
                f=band/31;colour=tuple(round(a+(b-a)*f) for a,b in zip((44,141,169),(16,83,126)))
                pygame.draw.rect(SCREEN,colour,(0,round(HEIGHT*band/32),WIDTH,math.ceil(HEIGHT/32)))
            self.draw_final_celebration();self.restart_button.draw()
            if getattr(self,"fullscreen",False):
                pygame.draw.rect(SCREEN,(243,233,204),self.exit_fullscreen_button,border_radius=6)
                label=TINY_FONT.render("Exit fullscreen [Esc]",True,DARK_GREEN)
                SCREEN.blit(label,label.get_rect(center=self.exit_fullscreen_button.center))
            return
        paused = self.state == "playing" and (
            self.manual_pause or self.menu_visible or self.line_input.active or self.circle_entry)
        key = (WIDTH, HEIGHT, SCALE, id(self.beach), id(self.trail_surface),
               self.scene_time, self.turtle_x, self.turtle_y, self.turtle_angle,
               self.crawl_phase, self.shell_fold,
               bool(self.show_grid or self.line_input.active or self.circle_entry),
               tuple(id(line) for line in self.lines),
               tuple((tuple(b['circle']), b['super']) for b in self.traps))
        if paused and getattr(self, '_paused_world_key', None) == key:
            SCREEN.blit(self._paused_world, (0, 0))
        else:
            self.draw_beach_world()
            if paused:
                # At most one screen-sized snapshot. Size/round/grid changes
                # invalidate it, and no UI is baked into this image.
                self._paused_world = SCREEN.copy()
                self._paused_world_key = key
            else:
                self._paused_world = None
                self._paused_world_key = None
        if self.circle_entry:
            self.draw_traps(preview_only=True)
        if self.state=="playing":
            self.draw_panel()
            if self.circle_entry:self.draw_circle_entry()
            if self.manual_pause and not self.menu_visible:
                text = FONT.render(
                    "Paused — click Resume to continue", True, DARK_GREEN
                )
                box = text.get_rect(center=(WIDTH // 2, HEIGHT // 2))
                box.inflate_ip(20, 12)
                pygame.draw.rect(SCREEN, (248, 243, 225), box, border_radius=8)
                SCREEN.blit(text, text.get_rect(center=box.center))
        elif self.state=="shop":
            self.draw_shop()
        elif self.state=="game_over":
            card=pygame.Rect(WIDTH//2-255,HEIGHT//2-130,510,260)
            pygame.draw.rect(SCREEN,(248,243,225),card,border_radius=12)
            text=TITLE_FONT.render("A hawk caught the turtle",True,RED)
            SCREEN.blit(text,text.get_rect(midtop=(card.centerx,card.y+30)))
            text=SMALL_FONT.render("Press Enter or click Try Again",True,BLACK)
            SCREEN.blit(text,text.get_rect(midtop=(card.centerx,card.y+95)))
            self.retry_button.draw()
        else:
            self.draw_score_card()
            (self.restart_button if self.state=="won" else self.next_button).draw()
        if getattr(self,"fullscreen",False):
            pygame.draw.rect(SCREEN,(243,233,204),self.exit_fullscreen_button,border_radius=6)
            text=TINY_FONT.render("Exit fullscreen [Esc]",True,DARK_GREEN)
            SCREEN.blit(text,text.get_rect(center=self.exit_fullscreen_button.center))


def configure_view(size, game=None, round_side=None):
    """Anchor the horizontal world span, adjusting vertical sand to the window.

    The scale depends only on the current viewport, never on resize history,
    input state, or the turtle position. Round geometry stays in world coordinates.
    """
    global WIDTH,HEIGHT,GRAPH_SIZE,GRAPH_W,GRAPH_LEFT,GRAPH_TOP,SCALE,SCREEN
    global X_MIN,X_MAX,Y_MIN,Y_MAX,HAWK_BEAK_REACH
    w,h=size
    # Ignore transient minimized / mode-switch dimensions. Normalizing an almost
    # zero height could otherwise allocate a huge canvas before the next event.
    if w<64 or h<64:return
    factor=max(BASE_WIDTH/w,BASE_HEIGHT/h)
    target=round(w*factor),round(h*factor)
    if target[0]*target[1]>12_000_000:return
    side=round_side if round_side is not None else getattr(game,"start_side","left")
    required_y=BASE_Y if side in ("top","bottom") else MIN_VISIBLE_Y
    new_scale=min(target[0]/(2*BASE_X),target[1]/(2*required_y))
    if game is not None and SCREEN.get_size()==target and abs(SCALE-new_scale)<1e-9:return
    # Keep up to three previous layouts for this round. Returning from fullscreen
    # should reuse its artwork, not repeat the slow procedural rock painting.
    fields=("beach","rock_art","collision_masks","contact_circles","obstacles",
            "obstacle_kinds","object_polygons")
    if game is not None:
        old_key=(WIDTH,HEIGHT)
        game._view_cache.pop(old_key,None)
        game._view_cache[old_key]=tuple(getattr(game,name) for name in fields)
        while len(game._view_cache)>3:game._view_cache.pop(next(iter(game._view_cache)))
    WIDTH,HEIGHT=target;GRAPH_W=WIDTH;GRAPH_SIZE=HEIGHT;GRAPH_LEFT=GRAPH_TOP=0
    # Decorated 16:9 screens have a slightly shorter client area. Trim peripheral
    # vertical sand rather than expanding the horizontal coordinate range.
    # Vertical journeys keep the full base height so maximizing cannot crop the
    # turtle at the upper/lower edge. Positions remain fixed in graph coordinates.
    SCALE=new_scale
    X_MIN,X_MAX=-WIDTH/(2*SCALE),WIDTH/(2*SCALE)
    Y_MIN,Y_MAX=-HEIGHT/(2*SCALE),HEIGHT/(2*SCALE)
    # Hawk art scales with the world; its collision/reversal reach is world-sized.
    HAWK_BEAK_REACH=22.0/(850/40)
    SCREEN=pygame.Surface((WIDTH,HEIGHT)).convert()
    if game is not None:
        cached=game._view_cache.get(target)
        if cached is not None:
            for name,value in zip(fields,cached):setattr(game,name,value)
        else:
            game.obstacles=[list(poly) for poly in game.object_polygons]
            game.collision_masks=None
            if game.level==9:
                game.obstacles=game.make_final_obstacles()
                game.object_polygons=[list(poly) for poly in game.obstacles]
            game.make_beach_background();game.make_rock_art()
        game.rebuild_trail();game.layout_controls()
        for hawk in game.hawks:
            hawk.beak_reach=HAWK_BEAK_REACH*hawk.size_factor
            endpoints=hawk.line.visible_endpoints()
            if len(endpoints)==2:
                low,high=sorted(x*hawk.line.dx+y*hawk.line.dy for x,y in endpoints)
                margin=min(hawk.beak_reach+.02,(high-low)*.35)
                if hawk.t<low+margin:hawk.t=low+margin;hawk.direction=1
                elif hawk.t>high-margin:hawk.t=high-margin;hawk.direction=-1


def logical_mouse_event(event):
    if hasattr(event,"pos"):
        values=event.dict.copy();w,h=WINDOW.get_size()
        values["pos"]=(round(event.pos[0]*WIDTH/w),round(event.pos[1]*HEIGHT/h))
        return pygame.event.Event(event.type,values)
    return event


_presentation_buffer = None

def present_frame():
    """Paint only the current display surface; never retain a pre-switch surface."""
    global WINDOW
    current=pygame.display.get_surface()
    if current is None:return
    WINDOW=current
    w,h=WINDOW.get_size()
    if w<=0 or h<=0:return
    if SCREEN.get_size() == (w, h):
        WINDOW.blit(SCREEN, (0, 0))
    else:
        # Reuse the output buffer; retain smooth scaling and the existing view.
        global _presentation_buffer
        if _presentation_buffer is None or _presentation_buffer.get_size() != (w, h):
            _presentation_buffer = pygame.Surface((w, h)).convert()
        pygame.transform.smoothscale(SCREEN, (w, h), _presentation_buffer)
        WINDOW.blit(_presentation_buffer, (0, 0))
    pygame.display.flip()


def change_fullscreen(enter, windowed_size):
    """Use the public display API exclusively, returning the actual mode and error.

    A failed fullscreen request restores a decorated window without touching
    round data. Keep this path independent of pygame's experimental Window API:
    changing the SDL window directly can invalidate the display module's surface.
    """
    global WINDOW
    def restore_window():
        global WINDOW
        WINDOW=pygame.display.set_mode(windowed_size,pygame.RESIZABLE)
        # A few SDL backends clear fullscreen first and apply the size second.
        if WINDOW.get_size()!=windowed_size:
            WINDOW=pygame.display.set_mode(windowed_size,pygame.RESIZABLE)
        present_frame()

    try:
        if enter:
            desktop=pygame.display.get_desktop_sizes()[0]
            WINDOW=pygame.display.set_mode(desktop,pygame.FULLSCREEN)
            present_frame()
        else:
            restore_window()
        return bool(WINDOW.get_flags() & pygame.FULLSCREEN),None
    except pygame.error:
        # The public set_mode call refreshes Pygame's display bookkeeping too.
        # Recover the playable window even if the failure happened during flip.
        restore_window()
        return False,"Fullscreen is unavailable. Continue in this window, or use the maximize button."


async def main():
    global WINDOW
    configure_view(WINDOW.get_size())
    game=Game();running=True;fullscreen=False;windowed_size=WINDOW.get_size()
    while running:
        dt=min(CLOCK.tick(60)/1000,.05)
        events=pygame.event.get()
        resize=False;toggle=False
        for event in events:
            if event.type==pygame.QUIT:running=False
            elif event.type==pygame.KEYDOWN and (event.key==pygame.K_F11 or (fullscreen and event.key==pygame.K_ESCAPE)):
                if not getattr(event,"repeat",False):toggle=True
            elif event.type in (pygame.VIDEORESIZE,pygame.WINDOWSIZECHANGED,pygame.WINDOWRESIZED,pygame.WINDOWRESTORED,pygame.WINDOWMAXIMIZED):
                WINDOW=pygame.display.get_surface();resize=True
                if not fullscreen:windowed_size=WINDOW.get_size()
            else:game.handle_event(logical_mouse_event(event))
        if game.fullscreen_requested:
            toggle=True;game.fullscreen_requested=False
        if toggle:
            if not fullscreen:windowed_size=WINDOW.get_size()
            fullscreen,error=change_fullscreen(not fullscreen,windowed_size)
            if error:
                game.message=error;game.message_colour=RED
                game.line_input.active=False;game.menu_visible=True
            resize=True
        game.fullscreen=fullscreen
        if resize:
            # Paint before rebuilding any uncached resources, so the OS never
            # displays a blank surface while procedural art is being generated.
            present_frame()
            configure_view(WINDOW.get_size(),game)
        game.update(dt);game.draw()
        present_frame()
        await asyncio.sleep(0)
    pygame.quit()




if __name__=="__main__":asyncio.run(main())
